﻿const store = require('./utils/store')

App({
  globalData: {
    baseUrl: 'http://127.0.0.1:5001',
    verifyBaseUrl: 'http://127.0.0.1:5001',
    // 本地开发登录开关；真实微信登录时必须关闭。
    allowDevLogin: false,
    devOpenid: '',
    unreadCount: 0
  },

  onLaunch() {
    store.bootstrap()
  }
})
