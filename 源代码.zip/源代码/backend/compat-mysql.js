"use strict"

function createCompatMysql({ query, sql, ok, config, crypto }) {
  const currentUserId = Number(process.env.DEMO_USER_ID || 1)

  function rows(stdout) {
    return String(stdout || "")
      .trim()
      .split(/\r?\n/)
      .filter(Boolean)
      .map((line) => line.split("\t").map((value) => value === "NULL" ? "" : value))
  }

  function num(value, fallback = 0) {
    const n = Number(value)
    return Number.isFinite(n) ? n : fallback
  }

  function jsonValue(value, fallback) {
    if (!value) return fallback
    try {
      return JSON.parse(value)
    } catch (error) {
      return fallback
    }
  }

  function sqlJson(value) {
    return `CAST(${sql(JSON.stringify(value === undefined ? null : value))} AS JSON)`
  }

  function nowText() {
    const d = new Date()
    const mm = String(d.getMonth() + 1).padStart(2, "0")
    const dd = String(d.getDate()).padStart(2, "0")
    const hh = String(d.getHours()).padStart(2, "0")
    const mi = String(d.getMinutes()).padStart(2, "0")
    return `${mm}-${dd} ${hh}:${mi}`
  }

  function dateText(value) {
    if (!value) return ""
    const text = String(value)
    const match = text.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/)
    return match ? `${match[2]}-${match[3]} ${match[4]}:${match[5]}` : text
  }

  function initial(name) {
    return String(name || "同").trim().charAt(0) || "同"
  }

  function statusText(status) {
    const map = {
      unpaid: "待支付",
      paid: "已托管",
      shipped: "履约中",
      confirmed: "已确认",
      completed: "已完成",
      refunding: "售后中",
      refunded: "已退款",
      cancelled: "已取消",
      disputed: "申诉中",
      on_sale: "已发布",
      pending: "审核中",
      rejected: "已驳回",
      removed: "已下架",
      waiting_accept: "待接单",
      accepted: "已接单",
      processing: "进行中"
    }
    return map[status] || status || "处理中"
  }

  function fundText(status) {
    const map = {
      none: "未托管",
      frozen: "资金托管中",
      settled: "已结算",
      refunded: "已退款"
    }
    return map[status || "none"] || "未托管"
  }

  function itemTypeText(type) {
    if (type === "service") return "校园服务"
    if (type === "errand") return "跑腿任务"
    return "二手闲置"
  }

  async function exec(sqlText) {
    return rows(await query(sqlText))
  }

  async function ensureDemoUser() {
    await query(`
      INSERT INTO users
        (id, openid, nickname, username, role, status, is_verified, credit_score, balance, frozen_balance)
      VALUES
        (${currentUserId}, ${sql(`mock-openid-${currentUserId}`)}, '校园同学', 'campus_user', 'user', 'active', 1, 100, 128.60, 0.00)
      ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;
    `)
  }

  async function ensureCategory(name, type) {
    const categoryName = String(name || (type === "goods" ? "其他" : "校园服务")).trim()
    await query(`
      INSERT INTO categories (name, type, status)
      VALUES (${sql(categoryName)}, ${sql(type)}, 'active')
      ON DUPLICATE KEY UPDATE status = 'active';
    `)
    const result = await exec(`
      SELECT id FROM categories
      WHERE name = ${sql(categoryName)} AND type = ${sql(type)}
      LIMIT 1;
    `)
    return num(result[0] && result[0][0], 1)
  }

  async function ensureUserByUsername(username, nickname, avatar) {
    const safeUsername = String(username || "").trim()
    if (!safeUsername) return currentUserId
    const found = await exec(`SELECT id FROM users WHERE username = ${sql(safeUsername)} LIMIT 1;`)
    if (found.length) return num(found[0][0], currentUserId)
    await query(`
      INSERT INTO users (openid, nickname, username, avatar_url, role, status, is_verified, credit_score, balance, frozen_balance)
      VALUES (${sql(`compat-${safeUsername}`)}, ${sql(nickname || safeUsername)}, ${sql(safeUsername)}, ${sql(avatar || "")}, 'user', 'active', 1, 100, 0.00, 0.00);
    `)
    const rowsAfter = await exec(`SELECT id FROM users WHERE username = ${sql(safeUsername)} LIMIT 1;`)
    return num(rowsAfter[0] && rowsAfter[0][0], currentUserId)
  }

  function userFromRow(row) {
    return {
      id: num(row[0], currentUserId),
      nickname: row[1] || "校园同学",
      username: row[2] || "campus_user",
      avatar: row[3] || "",
      phone: row[4] || "",
      address: row[5] || "",
      role: row[6] || "user",
      status: row[7] || "active",
      verified: num(row[8]) === 1,
      creditScore: num(row[9], 100),
      balance: num(row[10], 0)
    }
  }

  async function currentUser() {
    await ensureDemoUser()
    const result = await exec(`
      SELECT id, nickname, username, COALESCE(avatar_url, ''), COALESCE(phone_enc, ''),
             COALESCE(address, ''), role, status, is_verified, credit_score, balance
      FROM users WHERE id = ${currentUserId} LIMIT 1;
    `)
    return userFromRow(result[0])
  }

  async function publicUser(userId) {
    const id = num(userId, currentUserId)
    const result = await exec(`
      SELECT id, nickname, username, COALESCE(avatar_url, ''), COALESCE(phone_enc, ''),
             COALESCE(address, ''), role, status, is_verified, credit_score, balance
      FROM users WHERE id = ${id} LIMIT 1;
    `)
    if (!result.length) throw new Error("用户不存在")
    const user = userFromRow(result[0])
    const goods = (await goodsRows(`g.seller_id = ${id} AND g.status = 'on_sale'`)).map(goodsFromRow)
    const services = (await exec(`
      SELECT s.id, s.title, s.price, s.description, s.status, COALESCE(c.name, '校园服务'),
             s.provider_id, COALESCE(CAST(s.images AS CHAR), '[]'), s.avg_score,
             COALESCE(CAST(s.images AS CHAR), '[]'), u.nickname, u.username, COALESCE(u.avatar_url, ''),
             DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i:%s')
      FROM services s
      JOIN users u ON u.id = s.provider_id
      LEFT JOIN categories c ON c.id = s.category_id
      WHERE s.provider_id = ${id} AND s.status = 'on_sale'
      ORDER BY s.created_at DESC;
    `)).map(serviceFromRow)
    return {
      user: Object.assign(user, {
        reviewCount: 0,
        completedCount: 0,
        goodRate: 100,
        activeGoodsCount: goods.length,
        activeServiceCount: services.length,
        soldCount: 0
      }),
      reviews: [],
      goods,
      services
    }
  }

  function goodsFromRow(row) {
    const images = jsonValue(row[8], [])
    const sellerName = row[14] || "同校用户"
    return {
      id: num(row[0]),
      sellerId: num(row[1]),
      category: row[2] || "其他",
      title: row[3] || "",
      price: num(row[4], 0),
      condition: row[5] || "正常使用",
      desc: row[6] || "",
      image: images.find(Boolean) || "",
      images,
      imageObjects: [],
      location: row[9] || "校内自提",
      status: row[10] || "on_sale",
      auditNote: row[11] || "",
      favoriteCount: num(row[12]),
      viewCount: num(row[13]),
      sellerName,
      username: row[15] || "user",
      sellerAvatar: row[16] || "",
      sellerInitial: initial(sellerName),
      favorite: num(row[17]) === 1,
      createdAt: dateText(row[18]),
      createdTs: new Date(row[18] || Date.now()).getTime() || num(row[0])
    }
  }

  async function goodsRows(whereSql = "1=1", orderSql = "g.created_at DESC") {
    return exec(`
      SELECT g.id, g.seller_id, COALESCE(c.name, ''), g.title, g.price, g.condition_level,
             g.description, COALESCE(JSON_UNQUOTE(JSON_EXTRACT(g.images, '$[0]')), ''),
             COALESCE(CAST(g.images AS CHAR), '[]'), COALESCE(g.location, ''), g.status,
             COALESCE(g.audit_note, ''), g.favorite_count, g.view_count,
             u.nickname, u.username, COALESCE(u.avatar_url, ''),
             EXISTS(SELECT 1 FROM favorites f WHERE f.user_id = ${currentUserId} AND f.target_type = 'goods' AND f.target_id = g.id),
             DATE_FORMAT(g.created_at, '%Y-%m-%d %H:%i:%s')
      FROM goods g
      JOIN users u ON u.id = g.seller_id
      LEFT JOIN categories c ON c.id = g.category_id
      WHERE ${whereSql}
      ORDER BY ${orderSql};
    `)
  }

  async function getGoodsList() {
    const list = (await goodsRows("g.status IN ('on_sale','reserved','sold','pending')")).map(goodsFromRow)
    const categories = (await exec("SELECT name FROM categories WHERE type = 'goods' AND status = 'active' ORDER BY sort_order, id;")).map((row) => row[0])
    return ok({ list, categories })
  }

  async function getGoodsDetail(id) {
    await query(`UPDATE goods SET view_count = view_count + 1 WHERE id = ${num(id)};`)
    const result = (await goodsRows(`g.id = ${num(id)}`)).map(goodsFromRow)
    if (!result.length) throw new Error("商品不存在")
    return ok(result[0])
  }

  async function saveGoods(data) {
    const user = await currentUser()
    const categoryId = await ensureCategory(data.category || "其他", "goods")
    const images = Array.isArray(data.images) ? data.images.filter(Boolean) : []
    const idRow = await exec(`
      INSERT INTO goods
        (seller_id, category_id, title, price, condition_level, description, images, location, status, audit_note, favorite_count, view_count)
      VALUES
        (${user.id}, ${categoryId}, ${sql(data.title || "未命名商品")}, ${num(data.price, 0.01)},
         ${sql(data.condition || "正常使用")}, ${sql(data.desc || data.description || "")},
         ${sqlJson(images)}, ${sql(data.location || "校内自提")}, 'on_sale', 'AI审核通过', 0, 0);
      SELECT LAST_INSERT_ID();
    `)
    return ok({ goodsId: num(idRow[0] && idRow[0][0]), status: "on_sale" })
  }

  async function favoriteGoods(data) {
    const id = num(data.id || data.goodsId)
    const exists = await exec(`SELECT id FROM favorites WHERE user_id = ${currentUserId} AND target_type = 'goods' AND target_id = ${id} LIMIT 1;`)
    if (exists.length) {
      await query(`
        DELETE FROM favorites WHERE id = ${num(exists[0][0])};
        UPDATE goods SET favorite_count = GREATEST(0, favorite_count - 1) WHERE id = ${id};
      `)
    } else {
      await query(`
        INSERT IGNORE INTO favorites (user_id, target_type, target_id) VALUES (${currentUserId}, 'goods', ${id});
        UPDATE goods SET favorite_count = favorite_count + 1 WHERE id = ${id};
      `)
    }
    const countRows = await exec(`SELECT favorite_count FROM goods WHERE id = ${id};`)
    return ok({ favorite: !exists.length, favoriteCount: num(countRows[0] && countRows[0][0]) })
  }

  function serviceFromRow(row) {
    const images = jsonValue(row[9], [])
    const ownerName = row[10] || "同校用户"
    return {
      id: num(row[0]),
      type: "service",
      title: row[1] || "",
      price: num(row[2], 0),
      desc: row[3] || "",
      status: row[4] || "on_sale",
      category: row[5] || "校园服务",
      provider: ownerName,
      username: row[11] || "user",
      ownerAvatar: row[12] || "",
      images,
      imageObjects: [],
      serviceTime: "",
      location: "",
      createdAt: dateText(row[13]),
      createdTs: new Date(row[13] || Date.now()).getTime() || num(row[0])
    }
  }

  function errandFromRow(row) {
    const publisherName = row[8] || "同校用户"
    const riderName = row[11] || ""
    const status = row[6] || "waiting_accept"
    return {
      id: num(row[0]),
      type: "errand",
      title: row[1] || "",
      price: num(row[2], 0),
      desc: row[3] || "",
      pickupLocation: row[4] || "",
      deliveryLocation: row[5] || "",
      location: [row[4], row[5]].filter(Boolean).join(" -> "),
      status,
      provider: riderName || (status === "waiting_accept" ? "待接单" : publisherName),
      username: row[9] || "user",
      publisherName,
      ownerAvatar: row[10] || "",
      riderName,
      riderUsername: row[12] || "",
      orderSn: row[13] || "",
      createdAt: dateText(row[14]),
      createdTs: new Date(row[14] || Date.now()).getTime() || num(row[0])
    }
  }

  function unpaidErrandFromOrderRow(row) {
    const snapshot = jsonValue(row[4], {})
    const orderSn = row[0]
    return {
      id: num(String(orderSn).replace(/\D/g, ""), Date.now()),
      orderSn,
      type: "errand",
      title: snapshot.title || row[1] || "跑腿",
      price: num(row[2], 0),
      desc: snapshot.desc || row[3] || "",
      pickupLocation: snapshot.pickupLocation || "",
      deliveryLocation: snapshot.deliveryLocation || "",
      location: snapshot.location || [snapshot.pickupLocation, snapshot.deliveryLocation].filter(Boolean).join(" -> "),
      status: "unpaid",
      provider: "待支付",
      username: row[5] || "campus_user",
      publisherName: row[6] || "校园同学",
      ownerAvatar: row[7] || "",
      createdAt: dateText(row[8]),
      createdTs: new Date(row[8] || Date.now()).getTime() || Date.now()
    }
  }

  async function serviceList() {
    const services = (await exec(`
      SELECT s.id, s.title, s.price, s.description, s.status, COALESCE(c.name, '校园服务'),
             s.provider_id, COALESCE(CAST(s.images AS CHAR), '[]'), s.avg_score,
             COALESCE(CAST(s.images AS CHAR), '[]'), u.nickname, u.username, COALESCE(u.avatar_url, ''),
             DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i:%s')
      FROM services s
      JOIN users u ON u.id = s.provider_id
      LEFT JOIN categories c ON c.id = s.category_id
      WHERE s.status IN ('on_sale','pending')
      ORDER BY s.created_at DESC;
    `)).map(serviceFromRow)

    const errands = (await exec(`
      SELECT e.id, e.title, e.fee, e.description, e.pickup_location, e.delivery_location, e.status,
             e.publisher_id, p.nickname, p.username, COALESCE(p.avatar_url, ''),
             COALESCE(r.nickname, ''), COALESCE(r.username, ''),
             COALESCE(o.order_sn, ''), DATE_FORMAT(e.created_at, '%Y-%m-%d %H:%i:%s')
      FROM errand_orders e
      JOIN users p ON p.id = e.publisher_id
      LEFT JOIN users r ON r.id = e.rider_id
      LEFT JOIN orders o ON o.item_type = 'errand' AND o.item_id = e.id
      WHERE e.status IN ('waiting_accept','accepted','processing','confirmed','completed')
      ORDER BY e.created_at DESC;
    `)).map(errandFromRow)

    // 跑腿待支付不进入 errand_orders，避免和 schema 的状态约束冲突。
    const unpaidErrands = (await exec(`
      SELECT o.order_sn, JSON_UNQUOTE(JSON_EXTRACT(o.item_snapshot, '$.title')), o.amount,
             COALESCE(o.remark, ''), CAST(o.item_snapshot AS CHAR), u.username, u.nickname,
             COALESCE(u.avatar_url, ''), DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i:%s')
      FROM orders o
      JOIN users u ON u.id = o.buyer_id
      WHERE o.item_type = 'errand' AND o.status = 'unpaid' AND o.buyer_id = ${currentUserId}
      ORDER BY o.created_at DESC;
    `)).map(unpaidErrandFromOrderRow)

    return ok({ list: unpaidErrands.concat(errands, services) })
  }

  async function saveService(data) {
    const user = await currentUser()
    const amount = num(data.price, 0.01)
    if (data.type === "errand") {
      const orderSn = `ER${Date.now()}`
      const snapshot = {
        title: data.title || "跑腿",
        desc: data.desc || "",
        pickupLocation: data.pickupLocation || "",
        deliveryLocation: data.deliveryLocation || "",
        location: data.location || [data.pickupLocation, data.deliveryLocation].filter(Boolean).join(" -> "),
        images: Array.isArray(data.images) ? data.images : []
      }
      await query(`
        INSERT INTO orders
          (order_sn, buyer_id, seller_id, item_type, item_id, item_snapshot, amount, status, remark)
        VALUES
          (${sql(orderSn)}, ${user.id}, ${user.id}, 'errand', 0, ${sqlJson(snapshot)}, ${amount}, 'unpaid', ${sql(data.desc || "")});

        INSERT INTO order_events (order_sn, from_status, to_status, operator_id, event_type, note)
        VALUES (${sql(orderSn)}, NULL, 'unpaid', ${user.id}, 'create_errand_order', '跑腿订单已创建，支付后进入任务大厅');
      `)
      return ok({ id: num(String(orderSn).replace(/\D/g, ""), Date.now()), orderSn, status: "unpaid" })
    }

    const categoryId = await ensureCategory(data.category || "校园服务", "service")
    const idRow = await exec(`
      INSERT INTO services (provider_id, category_id, title, price, description, images, status)
      VALUES (${user.id}, ${categoryId}, ${sql(data.title || "校园服务")}, ${amount},
              ${sql(data.desc || "")}, ${sqlJson(Array.isArray(data.images) ? data.images : [])}, 'on_sale');
      SELECT LAST_INSERT_ID();
    `)
    return ok({ id: num(idRow[0] && idRow[0][0]), status: "on_sale" })
  }

  function orderTimeline(order) {
    const list = [
      { title: order.itemType === "errand" ? "发起跑腿订单" : "创建订单", desc: "订单已创建", time: order.createdAt || nowText(), done: true }
    ]
    if (order.status !== "unpaid") {
      list.push({ title: "资金托管", desc: "支付后资金进入平台托管", time: order.paidAt || order.createdAt || "", done: true })
    } else {
      list.push({ title: "等待支付", desc: "支付后进入后续流程", time: "待完成", done: false })
    }
    if (["shipped", "accepted", "processing", "completed", "confirmed"].includes(order.status)) {
      list.push({ title: "订单推进", desc: "对方已接单并开始处理", time: "", done: true })
    }
    if (["completed", "confirmed"].includes(order.status)) {
      list.push({ title: "订单完成", desc: "交易已完成", time: order.completedAt || "", done: true })
    }
    return list.map((step, index) => Object.assign({ id: `${order.orderSn}-${index}`, className: step.done === false ? "timeline-dot pending" : "timeline-dot done" }, step))
  }

  function orderFromRow(row) {
    const snapshot = jsonValue(row[6], {})
    const order = {
      orderSn: row[0],
      itemId: num(row[1]),
      itemType: row[2] || "goods",
      title: snapshot.title || row[3] || "订单",
      amount: num(row[4]).toFixed(2),
      status: row[5] || "unpaid",
      role: num(row[14]) === currentUserId ? "buyer" : "seller",
      sellerName: row[8] || "同校用户",
      sellerUsername: row[9] || "",
      counterpartyName: row[8] || "同校用户",
      counterpartyUsername: row[9] || "",
      counterpartyAvatar: row[10] || "",
      buyerName: row[11] || "校园同学",
      buyerUsername: row[12] || "campus_user",
      counterpartyLabel: row[2] === "service" ? "服务者" : row[2] === "errand" ? "骑手" : "卖家",
      fundStatus: row[13] || "none",
      fundText: fundText(row[13]),
      itemTypeText: itemTypeText(row[2]),
      statusLabel: statusText(row[5]),
      createdAt: dateText(row[15]),
      createdTs: new Date(row[15] || Date.now()).getTime() || Date.now(),
      paidAt: dateText(row[16]),
      completedAt: dateText(row[17]),
      remark: row[18] || "",
      progressText: progressText(row[2], row[5]),
      canChat: !(row[2] === "errand" && !row[9]),
      autoConfirm: { enabled: false, deadlineText: "", remainingText: "", tip: "" }
    }
    if (order.itemType === "errand" && !order.counterpartyUsername) {
      order.counterpartyName = "待接单"
      order.counterpartyLabel = "骑手"
      order.counterpartyLine = "骑手：等待接单"
      order.canChat = false
    } else {
      order.counterpartyLine = `${order.counterpartyLabel}：${order.counterpartyName} @${order.counterpartyUsername}`
    }
    order.timeline = orderTimeline(order)
    order.summaryEvents = order.timeline.slice(0, 3).map((item) => item.title)
    return order
  }

  function progressText(type, status) {
    if (type === "errand" && status === "unpaid") return "跑腿订单已创建，支付后进入任务大厅"
    if (type === "errand" && status === "paid") return "跑腿费已托管，等待骑手接单"
    if (type === "errand" && status === "shipped") return "骑手已接单，等待配送完成"
    if (status === "unpaid") return "订单已创建，等待支付"
    if (status === "paid") return "资金托管中，等待对方履约"
    if (status === "completed") return "订单已完成，资金已结算"
    return statusText(status)
  }

  async function orderRows(whereSql = "1=1") {
    return exec(`
      SELECT o.order_sn, o.item_id, o.item_type,
             COALESCE(JSON_UNQUOTE(JSON_EXTRACT(o.item_snapshot, '$.title')), ''),
             o.amount, o.status, CAST(o.item_snapshot AS CHAR),
             o.seller_id, seller.nickname, seller.username, COALESCE(seller.avatar_url, ''),
             buyer.nickname, buyer.username, COALESCE(f.status, 'none'),
             o.buyer_id, DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i:%s'),
             COALESCE(DATE_FORMAT(o.paid_at, '%Y-%m-%d %H:%i:%s'), ''),
             COALESCE(DATE_FORMAT(o.completed_at, '%Y-%m-%d %H:%i:%s'), ''),
             COALESCE(o.remark, '')
      FROM orders o
      JOIN users buyer ON buyer.id = o.buyer_id
      JOIN users seller ON seller.id = o.seller_id
      LEFT JOIN order_funds f ON f.order_sn = o.order_sn
      WHERE ${whereSql}
      ORDER BY o.created_at DESC;
    `)
  }

  async function buildPublishRecords() {
    const goods = (await goodsRows(`g.seller_id = ${currentUserId}`)).map(goodsFromRow).map((item) => ({
      orderSn: `PUB-G-${item.id}`,
      itemId: item.id,
      itemType: "goods",
      title: item.title,
      amount: Number(item.price || 0).toFixed(2),
      status: item.status,
      statusLabel: statusText(item.status),
      role: "publisher",
      counterpartyName: "等待买家",
      counterpartyUsername: "",
      counterpartyLabel: "发布",
      counterpartyLine: `发布：${item.category || "闲置商品"} · ${item.location || "校内"}`,
      fundStatus: "none",
      fundText: fundText("none"),
      itemTypeText: itemTypeText("goods"),
      createdAt: item.createdAt,
      createdTs: item.createdTs,
      progressText: item.auditNote || "商品已发布，等待同学下单或联系。",
      isPublication: true,
      timeline: [{ id: `PUB-G-${item.id}-0`, title: "发布成功", desc: item.auditNote || "发布信息已同步到我的发布。", time: item.createdAt || "刚刚", done: true, className: "timeline-dot done" }]
    }))
    const services = (await exec(`
      SELECT s.id, s.title, s.price, s.description, s.status, COALESCE(c.name, '校园服务'),
             s.provider_id, COALESCE(CAST(s.images AS CHAR), '[]'), s.avg_score,
             COALESCE(CAST(s.images AS CHAR), '[]'), u.nickname, u.username, COALESCE(u.avatar_url, ''),
             DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i:%s')
      FROM services s
      JOIN users u ON u.id = s.provider_id
      LEFT JOIN categories c ON c.id = s.category_id
      WHERE s.provider_id = ${currentUserId}
      ORDER BY s.created_at DESC;
    `)).map(serviceFromRow).map((item) => ({
      orderSn: `PUB-S-${item.id}`,
      itemId: item.id,
      itemType: "service",
      title: item.title,
      amount: Number(item.price || 0).toFixed(2),
      status: item.status,
      statusLabel: statusText(item.status),
      role: "publisher",
      counterpartyName: "等待预约",
      counterpartyUsername: "",
      counterpartyLabel: "发布",
      counterpartyLine: `发布：校园服务 · ${item.location || "校内"}`,
      fundStatus: "none",
      fundText: fundText("none"),
      itemTypeText: itemTypeText("service"),
      createdAt: item.createdAt,
      createdTs: item.createdTs,
      progressText: "服务已发布，等待同学预约或咨询。",
      isPublication: true,
      timeline: [{ id: `PUB-S-${item.id}-0`, title: "发布成功", desc: "服务信息已同步到我的发布。", time: item.createdAt || "刚刚", done: true, className: "timeline-dot done" }]
    }))
    return goods.concat(services)
  }

  async function orderList() {
    const orders = (await orderRows(`o.buyer_id = ${currentUserId} OR o.seller_id = ${currentUserId}`)).map(orderFromRow)
    const list = orders.concat(await buildPublishRecords()).sort((a, b) => Number(b.createdTs || 0) - Number(a.createdTs || 0))
    return ok({ list })
  }

  async function orderDetail(orderSn) {
    const result = (await orderRows(`o.order_sn = ${sql(orderSn)}`)).map(orderFromRow)
    if (!result.length) throw new Error("订单不存在")
    return ok(result[0])
  }

  async function payOrder(data) {
    const orderSn = data.orderSn
    const orderRowsResult = await exec(`
      SELECT order_sn, buyer_id, seller_id, item_type, item_id, amount, status, CAST(item_snapshot AS CHAR), COALESCE(remark, '')
      FROM orders WHERE order_sn = ${sql(orderSn)} LIMIT 1;
    `)
    if (!orderRowsResult.length) throw new Error("订单不存在")
    const row = orderRowsResult[0]
    if (row[6] !== "unpaid") return ok({ status: row[6] })
    const amount = num(row[5])
    const balanceRows = await exec(`SELECT balance FROM users WHERE id = ${currentUserId};`)
    if (num(balanceRows[0] && balanceRows[0][0]) < amount) throw new Error("余额不足，请先充值")

    let itemId = num(row[4])
    if (row[3] === "errand" && itemId === 0) {
      const snapshot = jsonValue(row[7], {})
      const idRows = await exec(`
        INSERT INTO errand_orders
          (publisher_id, title, description, pickup_location, delivery_location, fee, status)
        VALUES
          (${num(row[1])}, ${sql(snapshot.title || "跑腿")}, ${sql(snapshot.desc || row[8] || "")},
           ${sql(snapshot.pickupLocation || "校内")}, ${sql(snapshot.deliveryLocation || "校内")},
           ${amount}, 'waiting_accept');
        SELECT LAST_INSERT_ID();
      `)
      itemId = num(idRows[0] && idRows[0][0])
    }

    await query(`
      UPDATE users SET balance = balance - ${amount} WHERE id = ${currentUserId} AND balance >= ${amount};
      UPDATE orders
      SET status = 'paid', paid_at = NOW(), item_id = ${itemId}, updated_at = CURRENT_TIMESTAMP
      WHERE order_sn = ${sql(orderSn)};
      INSERT INTO order_funds (order_sn, amount, status, frozen_at)
      VALUES (${sql(orderSn)}, ${amount}, 'frozen', NOW())
      ON DUPLICATE KEY UPDATE status = 'frozen', frozen_at = NOW(), updated_at = CURRENT_TIMESTAMP;
      INSERT INTO wallet_logs (user_id, order_sn, type, direction, amount, balance_after, title, note)
      SELECT ${currentUserId}, ${sql(orderSn)}, 'pay', 'out', ${amount}, balance, ${sql(`支付订单 ${orderSn}`)}, '小程序订单支付'
      FROM users WHERE id = ${currentUserId};
      INSERT INTO order_events (order_sn, from_status, to_status, operator_id, event_type, note)
      VALUES (${sql(orderSn)}, 'unpaid', 'paid', ${currentUserId}, 'pay_order', '支付成功，资金进入平台托管');
    `)
    const balanceAfter = await exec(`SELECT balance FROM users WHERE id = ${currentUserId};`)
    return ok({ status: "paid", balance: num(balanceAfter[0] && balanceAfter[0][0]) })
  }

  async function createGoodsOrServiceOrder(data, isService) {
    const id = num(isService ? data.id : data.goodsId)
    const result = isService
      ? await exec(`SELECT s.id, s.provider_id, s.title, s.price, s.description FROM services s WHERE s.id = ${id} LIMIT 1;`)
      : await exec(`SELECT g.id, g.seller_id, g.title, g.price, g.description FROM goods g WHERE g.id = ${id} LIMIT 1;`)
    if (!result.length) throw new Error(isService ? "服务不存在" : "商品不存在")
    const item = result[0]
    const prefix = isService ? "SV" : "CT"
    const orderSn = `${prefix}${Date.now()}`
    const snapshot = { title: item[2], desc: item[4] || "" }
    await query(`
      INSERT INTO orders
        (order_sn, buyer_id, seller_id, item_type, item_id, item_snapshot, amount, status, remark)
      VALUES
        (${sql(orderSn)}, ${currentUserId}, ${num(item[1])}, ${sql(isService ? "service" : "goods")},
         ${num(item[0])}, ${sqlJson(snapshot)}, ${num(item[3])}, 'unpaid', ${sql(data.remark || "")});
      INSERT INTO order_events (order_sn, from_status, to_status, operator_id, event_type, note)
      VALUES (${sql(orderSn)}, NULL, 'unpaid', ${currentUserId}, ${sql(isService ? "create_service_order" : "create_goods_order")}, '订单已创建，等待支付');
    `)
    return ok({ orderSn, status: "unpaid" })
  }

  async function cancelOrder(data) {
    const orderSn = data.orderSn
    const found = await exec(`SELECT status FROM orders WHERE order_sn = ${sql(orderSn)} LIMIT 1;`)
    if (!found.length) throw new Error("订单不存在")
    if (!["unpaid", "paid"].includes(found[0][0])) throw new Error("当前状态不允许取消")
    await query(`
      UPDATE orders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE order_sn = ${sql(orderSn)};
      INSERT INTO order_events (order_sn, from_status, to_status, operator_id, event_type, note)
      VALUES (${sql(orderSn)}, ${sql(found[0][0])}, 'cancelled', ${currentUserId}, 'cancel_order', '用户取消订单');
    `)
    return ok({ status: "cancelled" })
  }

  async function receiveOrder(data) {
    const orderSn = data.orderSn
    await query(`
      UPDATE orders SET status = 'completed', completed_at = NOW(), updated_at = CURRENT_TIMESTAMP WHERE order_sn = ${sql(orderSn)};
      UPDATE order_funds SET status = 'settled', settled_at = NOW(), updated_at = CURRENT_TIMESTAMP WHERE order_sn = ${sql(orderSn)};
      INSERT INTO order_events (order_sn, from_status, to_status, operator_id, event_type, note)
      VALUES (${sql(orderSn)}, NULL, 'completed', ${currentUserId}, 'complete_order', '订单完成');
    `)
    return ok({ status: "completed" })
  }

  async function takeErrand(data) {
    const id = num(data.id)
    const result = await exec(`SELECT publisher_id, status FROM errand_orders WHERE id = ${id} LIMIT 1;`)
    if (!result.length) throw new Error("任务不存在")
    if (num(result[0][0]) === currentUserId) throw new Error("不能抢自己发布的跑腿任务")
    if (result[0][1] !== "waiting_accept") throw new Error("任务已被接单或尚未支付")
    await query(`
      UPDATE errand_orders SET rider_id = ${currentUserId}, status = 'accepted', accepted_at = NOW() WHERE id = ${id};
      UPDATE orders SET seller_id = ${currentUserId}, status = 'shipped', updated_at = CURRENT_TIMESTAMP
      WHERE item_type = 'errand' AND item_id = ${id};
    `)
    const order = await exec(`SELECT order_sn FROM orders WHERE item_type = 'errand' AND item_id = ${id} LIMIT 1;`)
    return ok({ status: "accepted", orderSn: order[0] && order[0][0] })
  }

  function conversationSessionType(type) {
    if (type === "service") return "service_chat"
    if (type === "errand") return "task_chat"
    return "goods_chat"
  }

  async function ensureConversation(data) {
    const parsed = data.conversationId && String(data.conversationId).split("-")
    const parsedType = parsed && parsed.length > 1 ? parsed[0] : ""
    const parsedId = parsed && parsed.length > 1 ? parsed[1] : ""
    const numericConversationId = /^\d+$/.test(String(data.conversationId || "")) ? num(data.conversationId) : 0
    if (numericConversationId) {
      const found = await exec(`SELECT id, business_type, business_id, user_a_id, user_b_id FROM conversations WHERE id = ${numericConversationId} LIMIT 1;`)
      if (found.length) return conversationMeta(found[0])
    }

    const businessType = data.businessType || (data.goodsId ? "goods" : data.serviceId ? "service" : data.errandId ? "errand" : parsedType) || "goods"
    const businessId = num(data.businessId || data.goodsId || data.serviceId || data.errandId || parsedId)
    let peerId = 0
    let title = data.title || "交易沟通"
    if (data.peerUsername) {
      peerId = await ensureUserByUsername(data.peerUsername, data.peerName, data.peerAvatar)
    }
    if (!peerId && businessType === "goods") {
      const goods = await exec(`SELECT g.seller_id, g.title FROM goods g WHERE g.id = ${businessId} LIMIT 1;`)
      if (goods.length) {
        peerId = num(goods[0][0])
        title = data.title || goods[0][1]
      }
    }
    if (!peerId && businessType === "service") {
      const service = await exec(`SELECT provider_id, title FROM services WHERE id = ${businessId} LIMIT 1;`)
      if (service.length) {
        peerId = num(service[0][0])
        title = data.title || service[0][1]
      }
    }
    if (!peerId && businessType === "errand") {
      const errand = await exec(`SELECT COALESCE(rider_id, publisher_id), title FROM errand_orders WHERE id = ${businessId} LIMIT 1;`)
      if (errand.length) {
        peerId = num(errand[0][0])
        title = data.title || errand[0][1]
      }
    }
    if (!peerId || peerId === currentUserId) {
      peerId = await ensureUserByUsername(data.peerUsername || "trade_peer", data.peerName || "交易对象", data.peerAvatar || "")
    }
    const userA = Math.min(currentUserId, peerId)
    const userB = Math.max(currentUserId, peerId)
    await query(`
      INSERT IGNORE INTO conversations (session_type, business_type, business_id, user_a_id, user_b_id, last_message_at)
      VALUES (${sql(conversationSessionType(businessType))}, ${sql(businessType)}, ${businessId}, ${userA}, ${userB}, NOW());
    `)
    const found = await exec(`
      SELECT id, business_type, business_id, user_a_id, user_b_id
      FROM conversations
      WHERE business_type = ${sql(businessType)} AND business_id = ${businessId} AND user_a_id = ${userA} AND user_b_id = ${userB}
      LIMIT 1;
    `)
    const meta = await conversationMeta(found[0])
    meta.title = title
    return meta
  }

  async function conversationMeta(row) {
    const id = num(row[0])
    const businessType = row[1] || "goods"
    const businessId = num(row[2])
    const peerId = num(row[3]) === currentUserId ? num(row[4]) : num(row[3])
    const peerRows = await exec(`SELECT nickname, username, COALESCE(avatar_url, '') FROM users WHERE id = ${peerId} LIMIT 1;`)
    const peer = peerRows[0] || ["交易对象", "user", ""]
    let title = "交易沟通"
    if (businessType === "goods") {
      const item = await exec(`SELECT title FROM goods WHERE id = ${businessId} LIMIT 1;`)
      if (item.length) title = item[0][0]
    } else if (businessType === "service") {
      const item = await exec(`SELECT title FROM services WHERE id = ${businessId} LIMIT 1;`)
      if (item.length) title = item[0][0]
    } else if (businessType === "errand") {
      const item = await exec(`SELECT title FROM errand_orders WHERE id = ${businessId} LIMIT 1;`)
      if (item.length) title = item[0][0]
    }
    return {
      id: String(id),
      title,
      peer: peer[0],
      peerUsername: peer[1],
      peerAvatar: peer[2],
      peerInitial: initial(peer[0]),
      businessType,
      businessId
    }
  }

  async function messagesForConversation(meta) {
    const result = await exec(`
      SELECT m.id, m.sender_id, sender.nickname, sender.username, COALESCE(sender.avatar_url, ''),
             m.content, DATE_FORMAT(m.created_at, '%H:%i'), m.content_hash
      FROM messages m
      JOIN users sender ON sender.id = m.sender_id
      WHERE m.conversation_id = ${num(meta.id)}
      ORDER BY m.id ASC;
    `)
    return result.map((row) => ({
      id: num(row[0]),
      from: num(row[1]) === currentUserId ? "me" : "peer",
      senderName: row[2] || "",
      senderUsername: row[3] || "",
      senderAvatar: row[4] || "",
      senderInitial: initial(row[2]),
      content: row[5] || "",
      time: row[6] || "",
      hash: row[7] || ""
    }))
  }

  async function chatList() {
    const found = await exec(`
      SELECT c.id, c.business_type, c.business_id, c.user_a_id, c.user_b_id
      FROM conversations c
      WHERE c.user_a_id = ${currentUserId} OR c.user_b_id = ${currentUserId}
      ORDER BY COALESCE(c.last_message_at, c.created_at) DESC;
    `)
    const list = []
    for (const row of found) {
      const meta = await conversationMeta(row)
      const messages = await messagesForConversation(meta)
      list.push(Object.assign(meta, { messages, lastMessage: messages.length ? messages[messages.length - 1].content : "" }))
    }
    return ok({ list })
  }

  async function chatMessages(data) {
    const conversation = await ensureConversation(data)
    const list = await messagesForConversation(conversation)
    return ok({ conversation: Object.assign({}, conversation, { messages: list }), list })
  }

  async function chatSend(data) {
    const content = String(data.content || "").trim()
    if (!content) throw new Error("消息内容不能为空")
    const conversation = await ensureConversation(data)
    const convRows = await exec(`SELECT user_a_id, user_b_id FROM conversations WHERE id = ${num(conversation.id)} LIMIT 1;`)
    const receiverId = convRows.length && num(convRows[0][0]) === currentUserId ? num(convRows[0][1]) : num(convRows[0] && convRows[0][0])
    const lastHashRows = await exec(`SELECT content_hash FROM messages WHERE conversation_id = ${num(conversation.id)} ORDER BY id DESC LIMIT 1;`)
    const previousHash = lastHashRows[0] && lastHashRows[0][0] ? lastHashRows[0][0] : ""
    const contentHash = crypto.createHash("sha256").update(`${previousHash}:${content}:${Date.now()}`).digest("hex")
    await query(`
      INSERT INTO messages (conversation_id, sender_id, receiver_id, message_type, content, content_hash, previous_hash)
      VALUES (${num(conversation.id)}, ${currentUserId}, ${receiverId}, 'text', ${sql(content)}, ${sql(contentHash)}, ${previousHash ? sql(previousHash) : "NULL"});
      UPDATE conversations SET last_message_at = NOW() WHERE id = ${num(conversation.id)};
    `)
    return ok({ status: "sent" })
  }

  async function accountLogs() {
    const list = (await exec(`
      SELECT id, type, title, CASE WHEN direction = 'out' THEN -amount ELSE amount END,
             balance_after, DATE_FORMAT(created_at, '%m-%d %H:%i')
      FROM wallet_logs WHERE user_id = ${currentUserId}
      ORDER BY created_at DESC LIMIT 100;
    `)).map((row) => ({
      id: num(row[0]),
      type: row[1],
      title: row[2],
      amount: num(row[3]),
      balanceAfter: num(row[4]),
      time: row[5]
    }))
    return ok({ list })
  }

  async function get(pathname, data) {
    if (!pathname.startsWith("/api/")) return null
    if (pathname === "/api/user/profile") return ok(await currentUser())
    if (pathname === "/api/user/public") return ok(await publicUser(data.id))
    if (pathname === "/api/user/credit") return ok({ score: (await currentUser()).creditScore || 100, level: "优秀", records: [] })
    if (pathname === "/api/goods/list") return getGoodsList()
    if (pathname === "/api/goods/detail") return getGoodsDetail(data.id)
    if (pathname === "/api/goods/favorites") {
      const list = (await goodsRows(`EXISTS(SELECT 1 FROM favorites f WHERE f.user_id = ${currentUserId} AND f.target_type = 'goods' AND f.target_id = g.id)`)).map(goodsFromRow)
      return ok({ list })
    }
    if (pathname === "/api/goods/mine") {
      const list = (await goodsRows(`g.seller_id = ${currentUserId}`)).map(goodsFromRow)
      return ok({ list })
    }
    if (pathname === "/api/service/list") return serviceList()
    if (pathname === "/api/service/detail") {
      const list = (await serviceList()).data.list
      const detail = list.find((item) => Number(item.id) === Number(data.id) || item.orderSn === data.orderSn)
      if (!detail) throw new Error("服务不存在")
      return ok(Object.assign({}, detail, {
        owner: await currentUser(),
        ownerReviews: [],
        typeText: detail.type === "errand" ? "跑腿任务" : "校园服务",
        statusText: statusText(detail.status),
        detailItems: detail.type === "errand"
          ? ["发布者支付跑腿费后进入任务大厅", "骑手抢单后可通过聊天同步进度", "完成后发布者确认结算"]
          : ["预约后生成待支付订单", "付款后服务费进入平台托管", "完成后可评价服务者"]
      }))
    }
    if (pathname === "/api/order/list") return orderList()
    if (pathname === "/api/order/detail") return orderDetail(data.orderSn)
    if (pathname === "/api/chat/list") return chatList()
    if (pathname === "/api/chat/messages") return chatMessages(data)
    if (pathname === "/api/account/logs") return accountLogs()
    if (pathname === "/api/rider/earnings") return ok({ amount: 0, acceptedCount: 0, withdraws: [] })
    return null
  }

  async function post(pathname, data) {
    if (!pathname.startsWith("/api/")) return null
    if (pathname === "/api/auth/login") return ok({ token: "mysql-backend-token", user: await currentUser(), isLogin: true })
    if (pathname === "/api/auth/logout") return ok({})
    if (pathname === "/api/user/profile/update") {
      const current = await currentUser()
      await query(`
        UPDATE users
        SET nickname = ${sql(data.nickname || current.nickname)},
            username = ${sql(data.username || current.username)},
            phone_enc = ${sql(data.phone || "")},
            address = ${sql(data.address || "")},
            avatar_url = ${sql(data.avatar || current.avatar || "")},
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${currentUserId};
      `)
      return ok(await currentUser())
    }
    if (pathname === "/api/user/role") {
      const role = ["user", "provider", "rider", "admin"].includes(data.role) ? data.role : "user"
      await query(`UPDATE users SET role = ${sql(role)} WHERE id = ${currentUserId};`)
      return ok({ role })
    }
    if (pathname === "/api/oss/sts") return ok({ host: "mock://upload", policy: "local-demo" })
    if (pathname === "/api/goods/save") return saveGoods(data)
    if (pathname === "/api/goods/favorite") return favoriteGoods(data)
    if (pathname === "/api/goods/remove" || pathname === "/api/goods/relist") {
      const status = pathname === "/api/goods/remove" ? "removed" : "pending"
      await query(`UPDATE goods SET status = ${sql(status)}, updated_at = CURRENT_TIMESTAMP WHERE id = ${num(data.id)} AND seller_id = ${currentUserId};`)
      return ok({ status })
    }
    if (pathname === "/api/service/save") return saveService(data)
    if (pathname === "/api/order/create") return createGoodsOrServiceOrder(data, false)
    if (pathname === "/api/service/order") return createGoodsOrServiceOrder(data, true)
    if (pathname === "/api/order/pay") return payOrder(data)
    if (pathname === "/api/order/cancel") return cancelOrder(data)
    if (pathname === "/api/order/receive" || pathname === "/api/order/ship") return receiveOrder(data)
    if (pathname === "/api/rider/take") return takeErrand(data)
    if (pathname === "/api/rider/status") return ok({ status: data.status || "processing" })
    if (pathname === "/api/chat/send") return chatSend(data)
    if (pathname === "/api/rider/withdraw") return ok({ status: "pending" })
    return null
  }

  return { get, post }
}

module.exports = { createCompatMysql }
