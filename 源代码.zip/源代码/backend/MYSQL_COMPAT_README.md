# MySQL 持久化接入说明

本文说明当前小程序兼容接口如何接入真实 MySQL。小程序前端仍然请求后端 `/api/...`，不要让小程序直连 MySQL。

## 本次迁移范围

已迁移到 MySQL 持久化的兼容接口包括：

| 模块 | 接口 | 持久化表 |
| --- | --- | --- |
| 用户头像与资料 | `/api/user/profile`、`/api/user/profile/update`、`/api/user/public` | `users` |
| 商品发布与同步 | `/api/goods/save`、`/api/goods/list`、`/api/goods/detail`、`/api/goods/mine` | `goods`、`categories`、`favorites` |
| 热门商品 | `/api/goods/list` 返回 `favorite_count`、`view_count` | `goods.favorite_count`、`goods.view_count` |
| 收藏 | `/api/goods/favorite`、`/api/goods/favorites` | `favorites`、`goods.favorite_count` |
| 服务发布 | `/api/service/save`、`/api/service/list`、`/api/service/detail` | `services` |
| 跑腿待支付 | `/api/service/save` 创建跑腿单 | `orders` |
| 跑腿支付后进入大厅 | `/api/order/pay` | `orders`、`order_funds`、`wallet_logs`、`errand_orders`、`order_events` |
| 订单列表与详情 | `/api/order/list`、`/api/order/detail` | `orders`、`order_funds`、`goods`、`services` |
| 聊天会话与消息 | `/api/chat/list`、`/api/chat/messages`、`/api/chat/send` | `conversations`、`messages`、`users` |

跑腿的“待支付”状态不会写入 `errand_orders`，因为当前 schema 约束只允许 `waiting_accept`、`accepted`、`processing`、`completed` 等状态。待支付阶段存入 `orders.status='unpaid'`；支付成功后才生成 `errand_orders.status='waiting_accept'`，这样与现有数据库约束一致。

## 环境变量

在 `源代码/backend/.env` 中配置：

```env
PORT=3001

DB_HOST=127.0.0.1
DB_NAME=campus_trade
DB_USER=root
DB_PASSWORD=你的密码
MYSQL_BIN=C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe

COMPAT_STORAGE=mysql
DEMO_USER_ID=1
```

字段说明：

| 变量 | 说明 |
| --- | --- |
| `DB_HOST` | MySQL 主机地址，本机一般是 `127.0.0.1` |
| `DB_NAME` | 数据库名，默认 `campus_trade` |
| `DB_USER` | 后端连接 MySQL 的账号 |
| `DB_PASSWORD` | MySQL 密码 |
| `MYSQL_BIN` | `mysql.exe` 的完整路径；如果已加入 PATH，可写 `mysql` |
| `COMPAT_STORAGE` | 写 `mysql` 使用真实持久化；临时回退内存可写 `memory` |
| `DEMO_USER_ID` | 当前未接真实登录 token 时的演示用户 ID，默认 `1` |

## 初始化数据库

首次接入时按顺序执行：

```powershell
$env:MYSQL_PWD = '你的 root 密码'
$mysql = 'C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe'
$root = 'E:\软件\diama\源代码\database\mysql'

cmd.exe /c "`"$mysql`" -h 127.0.0.1 -P 3306 -u root --protocol=TCP --default-character-set=utf8mb4 --binary-mode=1 < `"$root\schema.sql`""
cmd.exe /c "`"$mysql`" -h 127.0.0.1 -P 3306 -u root --protocol=TCP --default-character-set=utf8mb4 --binary-mode=1 campus_trade < `"$root\seed.sql`""
cmd.exe /c "`"$mysql`" -h 127.0.0.1 -P 3306 -u root --protocol=TCP --default-character-set=utf8mb4 --binary-mode=1 campus_trade < `"$root\seed_more.sql`""

Remove-Item Env:\MYSQL_PWD
```

如果你已经初始化过数据库，不要重复执行 `schema.sql`，否则会重建表并清空旧数据。

## 启动后端

```powershell
cd E:\软件\diama\源代码\backend
copy .env.example .env
# 修改 .env 里的 DB_PASSWORD、MYSQL_BIN 等配置
powershell -ExecutionPolicy Bypass -File .\start-backend.ps1
```

启动后验证：

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3001/api/status
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3001/api/user/profile
```

小程序侧当前应指向：

```js
baseUrl: 'http://127.0.0.1:3001'
apiMode: 'remote'
useMock: false
```

## 当前限制

当前后端仍使用 `DEMO_USER_ID` 表示当前登录用户，适合本地联调。真正上线时需要把 token/session 与 `users.id` 绑定，替换掉固定用户 ID，否则多用户同时使用时会共享同一个当前用户上下文。
