-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: campus_trade
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `campus_trade`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `campus_trade` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `campus_trade`;

--
-- Table structure for table `admin_audit_logs`
--

DROP TABLE IF EXISTS `admin_audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint unsigned DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `target_type` varchar(40) NOT NULL,
  `target_id` varchar(64) NOT NULL,
  `before_data` json DEFAULT NULL,
  `after_data` json DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_admin_logs_admin_created` (`admin_id`,`created_at`),
  KEY `idx_admin_logs_target` (`target_type`,`target_id`),
  CONSTRAINT `fk_admin_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_logs`
--

LOCK TABLES `admin_audit_logs` WRITE;
/*!40000 ALTER TABLE `admin_audit_logs` DISABLE KEYS */;
INSERT INTO `admin_audit_logs` VALUES (1,NULL,'AI审核通过','goods','101',NULL,'{\"status\": \"on_sale\"}','系统文本与图片审核通过','127.0.0.1','2026-06-12 09:20:00'),(2,NULL,'售后申请进入仲裁池','order','CT202606120002','{\"status\": \"paid\"}','{\"status\": \"refunding\"}','买家提交售后申请','127.0.0.1','2026-06-12 10:40:00'),(3,99,'封禁用户','user','4','{\"status\": \"active\", \"credit_score\": 98}','{\"status\": \"banned\", \"credit_score\": 58}','发布违规信息并拒绝整改','127.0.0.1','2026-06-12 09:40:00'),(4,NULL,'security_roles_initialized','database','campus_trade',NULL,'{\"hosts\": [\"localhost\", \"127.0.0.1\"], \"roles\": [\"campus_app_role\", \"campus_readonly_role\", \"campus_backup_role\", \"campus_ops_role\", \"campus_migration_role\"], \"accounts\": [\"campus_app\", \"campus_readonly\", \"campus_backup\", \"campus_ops\", \"campus_migration\"]}','least privilege database accounts created','127.0.0.1','2026-06-12 14:17:41');
/*!40000 ALTER TABLE `admin_audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_admin_audit_logs_no_update` BEFORE UPDATE ON `admin_audit_logs` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'admin audit logs are append-only and cannot be updated';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_admin_audit_logs_no_delete` BEFORE DELETE ON `admin_audit_logs` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'admin audit logs cannot be deleted';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ai_audit_records`
--

DROP TABLE IF EXISTS `ai_audit_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_audit_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(30) NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `audit_type` varchar(30) NOT NULL,
  `provider` varchar(50) NOT NULL DEFAULT 'mock',
  `request_id` varchar(100) DEFAULT NULL,
  `risk_level` varchar(20) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `raw_result` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ai_target` (`target_type`,`target_id`,`created_at`),
  KEY `idx_ai_risk_created` (`risk_level`,`created_at`),
  CONSTRAINT `chk_ai_audit_type` CHECK ((`audit_type` in (_utf8mb4'generate_title',_utf8mb4'generate_desc',_utf8mb4'recommend_tags',_utf8mb4'text_audit',_utf8mb4'image_audit'))),
  CONSTRAINT `chk_ai_risk` CHECK ((`risk_level` in (_utf8mb4'pass',_utf8mb4'manual',_utf8mb4'reject'))),
  CONSTRAINT `chk_ai_target` CHECK ((`target_type` in (_utf8mb4'goods',_utf8mb4'service',_utf8mb4'comment',_utf8mb4'message')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_audit_records`
--

LOCK TABLES `ai_audit_records` WRITE;
/*!40000 ALTER TABLE `ai_audit_records` DISABLE KEYS */;
INSERT INTO `ai_audit_records` VALUES (1,'goods',101,'text_audit','mock-ai','ai-20260612-0001','pass','文本未命中风险词，图片清晰。','{\"tags\": [\"教材\", \"笔记\"], \"score\": 0.98}','2026-06-12 09:20:00'),(2,'goods',104,'text_audit','mock-ai','ai-20260612-0002','manual','命中人工复核规则。','{\"score\": 0.62, \"keywords\": [\"违规\"]}','2026-06-12 09:18:00'),(3,'goods',104,'recommend_tags','mock-ai','ai-20260612-0003','pass','生成商品标签建议。','{\"tags\": [\"生活用品\", \"待复核\"]}','2026-06-12 09:18:10');
/*!40000 ALTER TABLE `ai_audit_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_rules`
--

DROP TABLE IF EXISTS `ai_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_rules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(80) NOT NULL,
  `text_audit_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `image_audit_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `manual_risk_level` varchar(20) NOT NULL DEFAULT 'manual',
  `keywords` text,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ai_rules_name` (`rule_name`),
  KEY `fk_ai_rules_updated_by` (`updated_by`),
  CONSTRAINT `fk_ai_rules_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_ai_rules_level` CHECK ((`manual_risk_level` in (_utf8mb4'pass',_utf8mb4'manual',_utf8mb4'reject')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_rules`
--

LOCK TABLES `ai_rules` WRITE;
/*!40000 ALTER TABLE `ai_rules` DISABLE KEYS */;
INSERT INTO `ai_rules` VALUES (1,'default_publish_audit',1,1,'manual','违规,仿冒,危险品',99,'2026-06-12 09:00:00','2026-06-12 09:00:00');
/*!40000 ALTER TABLE `ai_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'goods',
  `sort_order` int NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categories_name_type` (`name`,`type`),
  KEY `idx_categories_type_status` (`type`,`status`),
  CONSTRAINT `chk_categories_status` CHECK ((`status` in (_utf8mb4'active',_utf8mb4'disabled'))),
  CONSTRAINT `chk_categories_type` CHECK ((`type` in (_utf8mb4'goods',_utf8mb4'service',_utf8mb4'errand')))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'教材资料','goods',10,'active','2026-06-01 09:00:00'),(2,'数码产品','goods',20,'active','2026-06-01 09:00:00'),(3,'生活用品','goods',30,'active','2026-06-01 09:00:00'),(4,'运动用品','goods',40,'active','2026-06-01 09:00:00'),(5,'校园服务','service',50,'active','2026-06-01 09:00:00'),(6,'跑腿配送','errand',60,'active','2026-06-01 09:00:00'),(7,'学习辅导','service',70,'active','2026-06-01 09:00:00');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(64) NOT NULL,
  `evaluator_id` bigint unsigned NOT NULL,
  `target_user_id` bigint unsigned NOT NULL,
  `target_type` varchar(20) NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `score` int NOT NULL,
  `content` varchar(500) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'normal',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_comments_target` (`target_type`,`target_id`,`created_at`),
  KEY `idx_comments_order` (`order_sn`),
  KEY `fk_comments_evaluator` (`evaluator_id`),
  KEY `fk_comments_target_user` (`target_user_id`),
  CONSTRAINT `fk_comments_evaluator` FOREIGN KEY (`evaluator_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_comments_order` FOREIGN KEY (`order_sn`) REFERENCES `orders` (`order_sn`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_comments_target_user` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_comments_score` CHECK ((`score` between 1 and 5)),
  CONSTRAINT `chk_comments_status` CHECK ((`status` in (_utf8mb4'normal',_utf8mb4'hidden',_utf8mb4'removed'))),
  CONSTRAINT `chk_comments_target` CHECK ((`target_type` in (_utf8mb4'goods',_utf8mb4'service',_utf8mb4'errand')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'CT202606100001',7,2,'goods',101,5,'教材保存很好，交易也准时。','normal','2026-06-10 20:30:00');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversations`
--

DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_type` varchar(30) NOT NULL,
  `business_type` varchar(30) NOT NULL,
  `business_id` bigint unsigned NOT NULL,
  `user_a_id` bigint unsigned NOT NULL,
  `user_b_id` bigint unsigned NOT NULL,
  `last_message_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_conversation_business_users` (`business_type`,`business_id`,`user_a_id`,`user_b_id`),
  KEY `idx_conversation_user_a` (`user_a_id`,`last_message_at`),
  KEY `idx_conversation_user_b` (`user_b_id`,`last_message_at`),
  CONSTRAINT `fk_conversation_user_a` FOREIGN KEY (`user_a_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_conversation_user_b` FOREIGN KEY (`user_b_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_conversation_type` CHECK ((`session_type` in (_utf8mb4'goods_chat',_utf8mb4'service_chat',_utf8mb4'task_chat',_utf8mb4'system_notice')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversations`
--

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
INSERT INTO `conversations` VALUES (1,'goods_chat','goods',101,1,2,'2026-06-12 20:12:00','2026-06-12 20:10:00'),(2,'goods_chat','goods',102,1,3,'2026-06-12 10:42:00','2026-06-12 10:35:00');
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_logs`
--

DROP TABLE IF EXISTS `credit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `change_value` int NOT NULL,
  `reason_type` varchar(40) NOT NULL,
  `reason_detail` varchar(255) DEFAULT NULL,
  `related_type` varchar(30) DEFAULT NULL,
  `related_id` varchar(64) DEFAULT NULL,
  `operator_id` bigint unsigned DEFAULT NULL,
  `score_after` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_credit_user_created` (`user_id`,`created_at`),
  KEY `idx_credit_related` (`related_type`,`related_id`),
  KEY `fk_credit_operator` (`operator_id`),
  CONSTRAINT `fk_credit_operator` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_credit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_credit_score_after` CHECK ((`score_after` between 0 and 100))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_logs`
--

LOCK TABLES `credit_logs` WRITE;
/*!40000 ALTER TABLE `credit_logs` DISABLE KEYS */;
INSERT INTO `credit_logs` VALUES (1,1,5,'verify_approved','实名认证通过','verification','1',99,100,'2026-06-09 09:10:00'),(2,1,2,'order_completed','完成校园交易','order','CT202606100001',NULL,100,'2026-06-10 20:30:00'),(3,4,-40,'violation','发布违规信息并拒绝整改','admin_action','ban-20260612',99,58,'2026-06-12 09:40:00');
/*!40000 ALTER TABLE `credit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errand_events`
--

DROP TABLE IF EXISTS `errand_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `errand_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `errand_id` bigint unsigned NOT NULL,
  `from_status` varchar(30) DEFAULT NULL,
  `to_status` varchar(30) NOT NULL,
  `operator_id` bigint unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_errand_events_errand` (`errand_id`,`created_at`),
  KEY `fk_errand_events_operator` (`operator_id`),
  CONSTRAINT `fk_errand_events_operator` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_errand_events_order` FOREIGN KEY (`errand_id`) REFERENCES `errand_orders` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errand_events`
--

LOCK TABLES `errand_events` WRITE;
/*!40000 ALTER TABLE `errand_events` DISABLE KEYS */;
INSERT INTO `errand_events` VALUES (1,202,NULL,'waiting_accept',1,'用户发布跑腿配送任务','2026-06-12 09:30:00'),(2,203,NULL,'waiting_accept',1,'用户发布跑腿配送任务','2026-06-11 18:50:00'),(3,203,'waiting_accept','accepted',6,'骑手接单','2026-06-11 19:00:00'),(4,203,'accepted','processing',6,'骑手开始配送','2026-06-11 19:12:00'),(5,203,'processing','completed',6,'骑手完成配送','2026-06-11 19:40:00'),(6,203,'completed','confirmed',1,'发布者确认完成','2026-06-11 20:00:00');
/*!40000 ALTER TABLE `errand_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errand_orders`
--

DROP TABLE IF EXISTS `errand_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `errand_orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `publisher_id` bigint unsigned NOT NULL,
  `rider_id` bigint unsigned DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `pickup_location` varchar(120) NOT NULL,
  `delivery_location` varchar(120) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'waiting_accept',
  `accepted_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_errand_status_created` (`status`,`created_at`),
  KEY `idx_errand_publisher_created` (`publisher_id`,`created_at`),
  KEY `idx_errand_rider_created` (`rider_id`,`created_at`),
  CONSTRAINT `fk_errand_publisher` FOREIGN KEY (`publisher_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_errand_rider` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_errand_fee` CHECK ((`fee` > 0)),
  CONSTRAINT `chk_errand_status` CHECK ((`status` in (_utf8mb4'waiting_accept',_utf8mb4'accepted',_utf8mb4'processing',_utf8mb4'completed',_utf8mb4'confirmed',_utf8mb4'cancelled',_utf8mb4'disputed')))
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errand_orders`
--

LOCK TABLES `errand_orders` WRITE;
/*!40000 ALTER TABLE `errand_orders` DISABLE KEYS */;
INSERT INTO `errand_orders` VALUES (202,1,NULL,'南区到北区文件配送','取件地点南区宿舍，送到北区实验楼。','南区宿舍','北区实验楼',5.00,'waiting_accept',NULL,NULL,'2026-06-12 09:30:00','2026-06-12 09:30:00'),(203,1,6,'东区到图书馆资料代取','帮忙到东区打印店取资料并送到图书馆二楼。','东区打印店','图书馆二楼',12.00,'confirmed','2026-06-11 19:00:00','2026-06-11 19:40:00','2026-06-11 18:50:00','2026-06-11 20:00:00');
/*!40000 ALTER TABLE `errand_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `target_type` varchar(20) NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_favorites_user_target` (`user_id`,`target_type`,`target_id`),
  KEY `idx_favorites_target` (`target_type`,`target_id`),
  CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_favorites_target` CHECK ((`target_type` in (_utf8mb4'goods',_utf8mb4'service')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (1,1,'goods',102,'2026-06-12 09:25:00'),(2,7,'goods',101,'2026-06-11 19:00:00');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `condition_level` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `images` json DEFAULT NULL,
  `location` varchar(120) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `audit_note` varchar(255) DEFAULT NULL,
  `is_ai_generated` tinyint(1) NOT NULL DEFAULT '0',
  `favorite_count` int NOT NULL DEFAULT '0',
  `view_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_goods_status_created` (`status`,`created_at`),
  KEY `idx_goods_category_status` (`category_id`,`status`),
  KEY `idx_goods_seller` (`seller_id`,`created_at`),
  FULLTEXT KEY `ft_goods_title_desc` (`title`,`description`),
  CONSTRAINT `fk_goods_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_goods_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_goods_price` CHECK ((`price` > 0)),
  CONSTRAINT `chk_goods_status` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'on_sale',_utf8mb4'rejected',_utf8mb4'reserved',_utf8mb4'sold',_utf8mb4'removed')))
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (101,2,1,'九成新高数教材与习题册',26.00,'九成新','教材保存完整，附带课堂笔记，适合期末复习。','[\"/uploads/goods/math-book.jpg\"]','北区宿舍','on_sale','AI审核通过',0,8,126,'2026-06-10 09:20:00','2026-06-12 09:20:00'),(102,3,2,'蓝牙键盘 低噪轻薄款',58.00,'八成新','可连接平板和电脑，电量正常，支持现场验货。','[\"/uploads/goods/keyboard.jpg\"]','图书馆门口','on_sale','AI审核通过',0,15,212,'2026-06-10 10:10:00','2026-06-12 09:30:00'),(103,4,3,'宿舍折叠收纳箱两只',18.00,'七成新','搬宿舍闲置，干净无破损。','[\"/uploads/goods/storage-box.jpg\"]','南区食堂','on_sale','AI审核通过',0,3,42,'2026-06-11 10:20:00','2026-06-12 08:40:00'),(104,1,3,'违规词测试商品',12.00,'八成新','用于演示 AI 命中人工复核队列。','[\"/uploads/goods/manual-review.jpg\"]','东区操场','pending','命中人工复核规则',1,0,9,'2026-06-12 09:18:00','2026-06-12 09:18:00');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `idempotency_keys`
--

DROP TABLE IF EXISTS `idempotency_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `idempotency_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `idempotency_key` varchar(80) NOT NULL,
  `request_path` varchar(120) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `response_code` int DEFAULT NULL,
  `response_body` json DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'processing',
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idempotency_user_key` (`user_id`,`idempotency_key`),
  KEY `idx_idempotency_status_lock` (`status`,`locked_until`),
  CONSTRAINT `fk_idempotency_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_idempotency_status` CHECK ((`status` in (_utf8mb4'processing',_utf8mb4'success',_utf8mb4'failed',_utf8mb4'expired')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idempotency_keys`
--

LOCK TABLES `idempotency_keys` WRITE;
/*!40000 ALTER TABLE `idempotency_keys` DISABLE KEYS */;
INSERT INTO `idempotency_keys` VALUES (1,1,'demo-pay-CT202606120001','/api/order/pay','aa7fc6cfa755b05518c60429fe9ed1255ab184fc75a6b01ace890ab21e00e169',200,'{\"status\": \"paid\", \"order_sn\": \"CT202606120001\"}','success',NULL,'2026-06-12 09:50:00','2026-06-12 09:50:01'),(2,1,'demo-refund-CT202606120002','/api/order/refund','050ecc87acd74c45d78ce0d853d24e84abbdc3e719b2d8231a1a580d4a925c72',200,'{\"status\": \"refunding\", \"order_sn\": \"CT202606120002\"}','success',NULL,'2026-06-12 10:40:00','2026-06-12 10:40:01'),(3,1,'smoke-verify-001','/api/smoke','04d588cb41b8022d1233924f0fe8280d9e2bb92cdc81658eb102ef9c42fc9452',200,'{\"ok\": true}','success',NULL,'2026-06-12 11:42:06','2026-06-12 11:42:06');
/*!40000 ALTER TABLE `idempotency_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_logs`
--

DROP TABLE IF EXISTS `job_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(80) NOT NULL,
  `status` varchar(20) NOT NULL,
  `scanned_count` int NOT NULL DEFAULT '0',
  `success_count` int NOT NULL DEFAULT '0',
  `fail_count` int NOT NULL DEFAULT '0',
  `message` varchar(500) DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_job_logs_name_created` (`job_name`,`created_at`),
  KEY `idx_job_logs_status_created` (`status`,`created_at`),
  CONSTRAINT `chk_job_logs_status` CHECK ((`status` in (_utf8mb4'running',_utf8mb4'success',_utf8mb4'failed',_utf8mb4'partial')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_logs`
--

LOCK TABLES `job_logs` WRITE;
/*!40000 ALTER TABLE `job_logs` DISABLE KEYS */;
INSERT INTO `job_logs` VALUES (1,'seed_data_loaded','success',1,1,0,'演示数据已装载','2026-06-12 10:45:00','2026-06-12 10:45:01','2026-06-12 10:45:01'),(2,'ops_events_install','success',2,2,0,'maintenance events created disabled; enable after review','2026-06-12 14:18:28','2026-06-12 14:18:28','2026-06-12 14:18:28');
/*!40000 ALTER TABLE `job_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint unsigned NOT NULL,
  `sender_id` bigint unsigned NOT NULL,
  `receiver_id` bigint unsigned NOT NULL,
  `message_type` varchar(20) NOT NULL DEFAULT 'text',
  `content` text NOT NULL,
  `content_hash` char(64) NOT NULL,
  `previous_hash` char(64) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'normal',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_messages_conversation` (`conversation_id`,`id`),
  KEY `idx_messages_sender_created` (`sender_id`,`created_at`),
  KEY `fk_messages_receiver` (`receiver_id`),
  CONSTRAINT `fk_messages_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_messages_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_messages_status` CHECK ((`status` in (_utf8mb4'normal',_utf8mb4'recalled',_utf8mb4'hidden'))),
  CONSTRAINT `chk_messages_type` CHECK ((`message_type` in (_utf8mb4'text',_utf8mb4'image',_utf8mb4'system',_utf8mb4'recalled')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,1,2,1,'text','教材还在，可以今天晚上北区宿舍楼下交易。','7448985f906e3772285a49a28d33e6ef9665cb60427213843a626fc83e07f4f7',NULL,'normal','2026-06-12 20:10:00'),(2,1,1,2,'text','好的，我下单后过去拿。','17cf4203457b77455b26b847d60036b83019c69c81442f3b2468cbc39f924362','7448985f906e3772285a49a28d33e6ef9665cb60427213843a626fc83e07f4f7','normal','2026-06-12 20:12:00'),(3,2,1,3,'text','键盘按键和描述不一致，我已经申请售后。','5cbc055a3a628fa896279c9723066f43132fe378e2324c4a9db538de1c3199b9',NULL,'normal','2026-06-12 10:42:00');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_messages_no_update_content` BEFORE UPDATE ON `messages` FOR EACH ROW BEGIN
  IF NOT (OLD.conversation_id <=> NEW.conversation_id)
     OR NOT (OLD.sender_id <=> NEW.sender_id)
     OR NOT (OLD.receiver_id <=> NEW.receiver_id)
     OR NOT (OLD.message_type <=> NEW.message_type)
     OR NOT (OLD.content <=> NEW.content)
     OR NOT (OLD.content_hash <=> NEW.content_hash)
     OR NOT (OLD.previous_hash <=> NEW.previous_hash) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'chat evidence content and hash chain cannot be updated';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_messages_no_delete` BEFORE DELETE ON `messages` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'chat evidence messages cannot be deleted';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `business_type` varchar(30) NOT NULL,
  `business_id` varchar(64) NOT NULL,
  `title` varchar(120) NOT NULL,
  `content` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`),
  KEY `idx_notifications_business` (`business_type`,`business_id`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_notifications_business` CHECK ((`business_type` in (_utf8mb4'order',_utf8mb4'goods',_utf8mb4'service',_utf8mb4'errand',_utf8mb4'refund',_utf8mb4'system')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,'order','CT202606120001','订单已支付','资金已进入平台托管，等待卖家履约。',0,'2026-06-12 09:50:00',NULL),(2,2,'order','CT202606120001','你有新的订单','买家已支付，请按约定时间交付商品。',0,'2026-06-12 09:50:00',NULL),(3,1,'refund','CT202606120002','售后已进入仲裁','平台管理员将根据订单与聊天证据处理。',1,'2026-06-12 10:45:00','2026-06-12 10:46:00');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_events`
--

DROP TABLE IF EXISTS `order_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(64) NOT NULL,
  `from_status` varchar(30) DEFAULT NULL,
  `to_status` varchar(30) NOT NULL,
  `operator_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(40) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_events_order` (`order_sn`,`created_at`),
  KEY `fk_order_events_operator` (`operator_id`),
  CONSTRAINT `fk_order_events_operator` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_order_events_order` FOREIGN KEY (`order_sn`) REFERENCES `orders` (`order_sn`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_events`
--

LOCK TABLES `order_events` WRITE;
/*!40000 ALTER TABLE `order_events` DISABLE KEYS */;
INSERT INTO `order_events` VALUES (1,'CT202606100001',NULL,'unpaid',7,'create','创建订单','2026-06-10 18:58:00'),(2,'CT202606100001','unpaid','paid',7,'pay','买家支付，资金托管','2026-06-10 19:00:00'),(3,'CT202606100001','paid','completed',7,'receive','买家确认收货，资金结算','2026-06-10 20:20:00'),(4,'CT202606120001',NULL,'unpaid',1,'create','创建订单','2026-06-12 09:48:00'),(5,'CT202606120001','unpaid','paid',1,'pay','买家支付，资金托管','2026-06-12 09:50:00'),(6,'CT202606120002',NULL,'unpaid',1,'create','创建订单','2026-06-12 09:58:00'),(7,'CT202606120002','unpaid','paid',1,'pay','买家支付，资金托管','2026-06-12 10:00:00'),(8,'CT202606120002','paid','refunding',1,'refund_apply','买家发起售后：描述与实物不符','2026-06-12 10:40:00'),(9,'SV202606120001',NULL,'unpaid',1,'create','预约服务','2026-06-12 09:08:00'),(10,'SV202606120001','unpaid','paid',1,'pay','服务费托管','2026-06-12 09:10:00'),(11,'ER202606110001',NULL,'paid',1,'errand_pay','跑腿费托管','2026-06-11 18:50:00'),(12,'ER202606110001','paid','completed',1,'errand_confirm','发布者确认完成，收益结算','2026-06-11 20:00:00');
/*!40000 ALTER TABLE `order_events` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_order_events_no_update` BEFORE UPDATE ON `order_events` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'order event trace is append-only and cannot be updated';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_order_events_no_delete` BEFORE DELETE ON `order_events` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'order event trace cannot be deleted';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `order_funds`
--

DROP TABLE IF EXISTS `order_funds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_funds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(64) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'none',
  `frozen_at` datetime DEFAULT NULL,
  `settled_at` datetime DEFAULT NULL,
  `refunded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_funds_order` (`order_sn`),
  KEY `idx_order_funds_status` (`status`,`created_at`),
  CONSTRAINT `fk_order_funds_order` FOREIGN KEY (`order_sn`) REFERENCES `orders` (`order_sn`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_order_funds_amount` CHECK ((`amount` > 0)),
  CONSTRAINT `chk_order_funds_status` CHECK ((`status` in (_utf8mb4'none',_utf8mb4'frozen',_utf8mb4'settled',_utf8mb4'refunded')))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_funds`
--

LOCK TABLES `order_funds` WRITE;
/*!40000 ALTER TABLE `order_funds` DISABLE KEYS */;
INSERT INTO `order_funds` VALUES (1,'CT202606100001',26.00,'settled','2026-06-10 19:00:00','2026-06-10 20:20:00',NULL,'2026-06-10 19:00:00','2026-06-10 20:20:00'),(2,'CT202606120001',26.00,'frozen','2026-06-12 09:50:00',NULL,NULL,'2026-06-12 09:50:00','2026-06-12 09:50:00'),(3,'CT202606120002',58.00,'frozen','2026-06-12 10:00:00',NULL,NULL,'2026-06-12 10:00:00','2026-06-12 10:40:00'),(4,'SV202606120001',6.00,'frozen','2026-06-12 09:10:00',NULL,NULL,'2026-06-12 09:10:00','2026-06-12 09:10:00'),(5,'ER202606110001',12.00,'settled','2026-06-11 18:50:00','2026-06-11 20:00:00',NULL,'2026-06-11 18:50:00','2026-06-11 20:00:00');
/*!40000 ALTER TABLE `order_funds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_sn` varchar(64) NOT NULL,
  `buyer_id` bigint unsigned NOT NULL,
  `seller_id` bigint unsigned NOT NULL,
  `item_type` varchar(20) NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `item_snapshot` json NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'unpaid',
  `remark` varchar(255) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_sn`),
  KEY `idx_orders_buyer_created` (`buyer_id`,`created_at`),
  KEY `idx_orders_seller_created` (`seller_id`,`created_at`),
  KEY `idx_orders_status_created` (`status`,`created_at`),
  KEY `idx_orders_item` (`item_type`,`item_id`),
  CONSTRAINT `fk_orders_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_orders_amount` CHECK ((`amount` > 0)),
  CONSTRAINT `chk_orders_item_type` CHECK ((`item_type` in (_utf8mb4'goods',_utf8mb4'service',_utf8mb4'errand'))),
  CONSTRAINT `chk_orders_status` CHECK ((`status` in (_utf8mb4'unpaid',_utf8mb4'paid',_utf8mb4'confirmed',_utf8mb4'shipped',_utf8mb4'completed',_utf8mb4'refunding',_utf8mb4'refunded',_utf8mb4'cancelled',_utf8mb4'disputed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('CT202606100001',7,2,'goods',101,'{\"price\": 26.00, \"title\": \"九成新高数教材与习题册\", \"location\": \"北区宿舍\"}',26.00,'completed','历史成交评价样例','2026-06-10 19:00:00','2026-06-10 20:20:00','2026-06-10 18:58:00','2026-06-10 20:20:00'),('CT202606120001',1,2,'goods',101,'{\"price\": 26.00, \"title\": \"九成新高数教材与习题册\", \"location\": \"北区宿舍\"}',26.00,'paid','今晚北区宿舍楼下交易','2026-06-12 09:50:00',NULL,'2026-06-12 09:48:00','2026-06-12 09:50:00'),('CT202606120002',1,3,'goods',102,'{\"price\": 58.00, \"title\": \"蓝牙键盘 低噪轻薄款\", \"location\": \"图书馆门口\"}',58.00,'refunding','描述与实物不符，申请售后','2026-06-12 10:00:00',NULL,'2026-06-12 09:58:00','2026-06-12 10:40:00'),('ER202606110001',1,6,'errand',203,'{\"price\": 12.00, \"rider\": \"跑腿同学\", \"title\": \"东区到图书馆资料代取\"}',12.00,'completed','跑腿任务完成','2026-06-11 18:50:00','2026-06-11 20:00:00','2026-06-11 18:50:00','2026-06-11 20:00:00'),('SV202606120001',1,5,'service',201,'{\"price\": 6.00, \"title\": \"资料整理与打印代办\", \"provider\": \"文印小站\"}',6.00,'paid','晚自习后交付','2026-06-12 09:10:00',NULL,'2026-06-12 09:08:00','2026-06-12 09:10:00');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_requests`
--

DROP TABLE IF EXISTS `refund_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(64) NOT NULL,
  `applicant_id` bigint unsigned NOT NULL,
  `seller_id` bigint unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `evidence_urls` json DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `seller_reply` varchar(255) DEFAULT NULL,
  `admin_id` bigint unsigned DEFAULT NULL,
  `arbitrate_result` varchar(30) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_refund_order` (`order_sn`),
  KEY `idx_refund_status_created` (`status`,`created_at`),
  KEY `fk_refund_applicant` (`applicant_id`),
  KEY `fk_refund_seller` (`seller_id`),
  KEY `fk_refund_admin` (`admin_id`),
  CONSTRAINT `fk_refund_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_refund_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_refund_order` FOREIGN KEY (`order_sn`) REFERENCES `orders` (`order_sn`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_refund_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_refund_status` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'seller_agreed',_utf8mb4'seller_rejected',_utf8mb4'arbitrating',_utf8mb4'buyer_win',_utf8mb4'seller_win',_utf8mb4'cancelled')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_requests`
--

LOCK TABLES `refund_requests` WRITE;
/*!40000 ALTER TABLE `refund_requests` DISABLE KEYS */;
INSERT INTO `refund_requests` VALUES (1,'CT202606120002',1,3,'描述与实物不符，键盘部分按键不灵敏。','[\"/uploads/evidence/keyboard-issue.jpg\"]','arbitrating','卖家表示可现场复验',99,NULL,NULL,'2026-06-12 10:40:00','2026-06-12 10:45:00');
/*!40000 ALTER TABLE `refund_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `images` json DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'on_sale',
  `avg_score` decimal(3,2) NOT NULL DEFAULT '5.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_services_provider` (`provider_id`,`created_at`),
  KEY `idx_services_category_status` (`category_id`,`status`),
  CONSTRAINT `fk_services_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_services_provider` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_services_price` CHECK ((`price` > 0)),
  CONSTRAINT `chk_services_status` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'on_sale',_utf8mb4'paused',_utf8mb4'removed')))
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (201,5,5,'资料整理与打印代办',6.00,'支持资料整理、打印、装订，可约晚自习后交付。','[\"/uploads/services/print.jpg\"]','on_sale',5.00,'2026-06-11 13:00:00','2026-06-12 09:00:00'),(202,7,7,'期末 C 语言答疑半小时',15.00,'可在图书馆或线上答疑，适合考前查漏补缺。','[\"/uploads/services/c-language.jpg\"]','on_sale',4.80,'2026-06-11 14:00:00','2026-06-12 09:00:00');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_daily`
--

DROP TABLE IF EXISTS `stats_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stats_daily` (
  `stat_date` date NOT NULL,
  `total_users` int NOT NULL DEFAULT '0',
  `active_users` int NOT NULL DEFAULT '0',
  `goods_on_sale` int NOT NULL DEFAULT '0',
  `order_count` int NOT NULL DEFAULT '0',
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `abnormal_order_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats_daily`
--

LOCK TABLES `stats_daily` WRITE;
/*!40000 ALTER TABLE `stats_daily` DISABLE KEYS */;
INSERT INTO `stats_daily` VALUES ('2026-06-12',8,7,3,3,90.00,0,'2026-06-12 10:50:00','2026-06-12 10:50:00');
/*!40000 ALTER TABLE `stats_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_verifications`
--

DROP TABLE IF EXISTS `user_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `student_id_enc` varchar(255) NOT NULL,
  `real_name_enc` varchar(255) NOT NULL,
  `college` varchar(64) NOT NULL,
  `student_card_image_url` varchar(255) DEFAULT NULL,
  `ocr_match_score` decimal(5,2) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `reviewer_id` bigint unsigned DEFAULT NULL,
  `review_note` varchar(255) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_verifications_user` (`user_id`,`created_at`),
  KEY `idx_user_verifications_status` (`status`,`created_at`),
  KEY `fk_user_verifications_reviewer` (`reviewer_id`),
  CONSTRAINT `fk_user_verifications_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_user_verifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_user_verifications_status` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'approved',_utf8mb4'rejected')))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verifications`
--

LOCK TABLES `user_verifications` WRITE;
/*!40000 ALTER TABLE `user_verifications` DISABLE KEYS */;
INSERT INTO `user_verifications` VALUES (1,1,'enc:20230001','enc:campus-user','软件学院','/uploads/verify/20230001.jpg',98.50,'approved',99,'学生证识别通过','2026-06-09 09:10:00','2026-06-09 09:00:00'),(2,2,'enc:20230002','enc:math-user','数学学院','/uploads/verify/20230002.jpg',96.20,'approved',99,'学生证识别通过','2026-06-09 09:20:00','2026-06-09 09:12:00'),(3,3,'enc:20230003','enc:se-user','软件学院','/uploads/verify/20230003.jpg',94.80,'approved',99,'学生证识别通过','2026-06-09 09:30:00','2026-06-09 09:18:00'),(4,4,'enc:20230004','enc:south-user','管理学院','/uploads/verify/20230004.jpg',95.00,'approved',99,'历史认证记录，当前因违规封禁','2026-06-09 09:40:00','2026-06-09 09:22:00');
/*!40000 ALTER TABLE `user_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(64) NOT NULL,
  `student_id_enc` varchar(255) DEFAULT NULL,
  `real_name_enc` varchar(255) DEFAULT NULL,
  `college` varchar(64) DEFAULT NULL,
  `nickname` varchar(64) NOT NULL DEFAULT '校园同学',
  `avatar_url` varchar(255) DEFAULT NULL,
  `phone_enc` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user',
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `credit_score` int NOT NULL DEFAULT '100',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `frozen_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_openid` (`openid`),
  UNIQUE KEY `uk_users_student` (`student_id_enc`),
  KEY `idx_users_role_status` (`role`,`status`),
  CONSTRAINT `chk_users_balance` CHECK (((`balance` >= 0) and (`frozen_balance` >= 0))),
  CONSTRAINT `chk_users_credit` CHECK ((`credit_score` between 0 and 100)),
  CONSTRAINT `chk_users_role` CHECK ((`role` in (_utf8mb4'user',_utf8mb4'provider',_utf8mb4'rider',_utf8mb4'admin'))),
  CONSTRAINT `chk_users_status` CHECK ((`status` in (_utf8mb4'active',_utf8mb4'pending_verify',_utf8mb4'banned',_utf8mb4'removed')))
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'mock-openid-001','enc:20230001','enc:campus-user','软件学院','校园同学','','enc:13800000001','北区宿舍 6 栋','user','active',1,100,38.60,0.00,'2026-06-01 09:00:00','2026-06-12 10:30:00'),(2,'mock-openid-002','enc:20230002','enc:math-user','数学学院','数院同学','','enc:13800000002','北区宿舍','user','active',1,96,46.00,0.00,'2026-06-02 10:00:00','2026-06-12 10:20:00'),(3,'mock-openid-003','enc:20230003','enc:se-user','软件学院','软件工程同学','','enc:13800000003','图书馆附近','user','active',1,91,32.00,0.00,'2026-06-03 11:00:00','2026-06-12 10:40:00'),(4,'mock-openid-004','enc:20230004','enc:south-user','管理学院','南区同学','','enc:13800000004','南区食堂','user','banned',1,58,0.00,0.00,'2026-06-04 12:00:00','2026-06-12 09:40:00'),(5,'mock-openid-005','enc:20230005','enc:print-shop','文学院','文印小站','','enc:13800000005','教学楼 A 区','provider','active',1,98,0.00,0.00,'2026-06-05 09:20:00','2026-06-12 09:20:00'),(6,'mock-openid-006','enc:20230006','enc:rider-user','体育学院','跑腿同学','','enc:13800000006','东区操场','rider','active',1,97,12.00,0.00,'2026-06-06 08:30:00','2026-06-12 09:30:00'),(7,'mock-openid-007','enc:20230007','enc:info-user','信息学院','信工同学','','enc:13800000007','东区宿舍','user','active',1,98,20.00,0.00,'2026-06-07 08:30:00','2026-06-11 19:30:00'),(99,'mock-openid-admin','enc:admin001','enc:admin-user','平台运营中心','平台管理员','','enc:13800000999','后台管理端','admin','active',1,100,0.00,0.00,'2026-06-01 08:00:00','2026-06-12 10:00:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_admin_order_summary`
--

DROP TABLE IF EXISTS `v_admin_order_summary`;
/*!50001 DROP VIEW IF EXISTS `v_admin_order_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_admin_order_summary` AS SELECT 
 1 AS `order_sn`,
 1 AS `item_type`,
 1 AS `item_id`,
 1 AS `item_title`,
 1 AS `amount`,
 1 AS `order_status`,
 1 AS `fund_status`,
 1 AS `created_at`,
 1 AS `paid_at`,
 1 AS `completed_at`,
 1 AS `buyer_name`,
 1 AS `seller_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_admin_pending_goods`
--

DROP TABLE IF EXISTS `v_admin_pending_goods`;
/*!50001 DROP VIEW IF EXISTS `v_admin_pending_goods`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_admin_pending_goods` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `price`,
 1 AS `condition_level`,
 1 AS `description`,
 1 AS `audit_note`,
 1 AS `created_at`,
 1 AS `category_name`,
 1 AS `seller_name`,
 1 AS `seller_credit_score`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_admin_refund_queue`
--

DROP TABLE IF EXISTS `v_admin_refund_queue`;
/*!50001 DROP VIEW IF EXISTS `v_admin_refund_queue`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_admin_refund_queue` AS SELECT 
 1 AS `refund_id`,
 1 AS `order_sn`,
 1 AS `reason`,
 1 AS `evidence_urls`,
 1 AS `refund_status`,
 1 AS `created_at`,
 1 AS `amount`,
 1 AS `order_status`,
 1 AS `applicant_name`,
 1 AS `seller_name`,
 1 AS `admin_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_chat_evidence_chain`
--

DROP TABLE IF EXISTS `v_chat_evidence_chain`;
/*!50001 DROP VIEW IF EXISTS `v_chat_evidence_chain`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_chat_evidence_chain` AS SELECT 
 1 AS `conversation_id`,
 1 AS `business_type`,
 1 AS `business_id`,
 1 AS `message_id`,
 1 AS `sender_name`,
 1 AS `receiver_name`,
 1 AS `message_type`,
 1 AS `content`,
 1 AS `content_hash`,
 1 AS `previous_hash`,
 1 AS `status`,
 1 AS `created_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_errand_hall`
--

DROP TABLE IF EXISTS `v_errand_hall`;
/*!50001 DROP VIEW IF EXISTS `v_errand_hall`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_errand_hall` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `description`,
 1 AS `pickup_location`,
 1 AS `delivery_location`,
 1 AS `fee`,
 1 AS `status`,
 1 AS `created_at`,
 1 AS `publisher_name`,
 1 AS `rider_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_goods_public_list`
--

DROP TABLE IF EXISTS `v_goods_public_list`;
/*!50001 DROP VIEW IF EXISTS `v_goods_public_list`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_goods_public_list` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `price`,
 1 AS `condition_level`,
 1 AS `description`,
 1 AS `images`,
 1 AS `location`,
 1 AS `favorite_count`,
 1 AS `view_count`,
 1 AS `created_at`,
 1 AS `category_name`,
 1 AS `seller_id`,
 1 AS `seller_name`,
 1 AS `seller_credit_score`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_order_trace`
--

DROP TABLE IF EXISTS `v_order_trace`;
/*!50001 DROP VIEW IF EXISTS `v_order_trace`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_order_trace` AS SELECT 
 1 AS `order_sn`,
 1 AS `item_type`,
 1 AS `item_title`,
 1 AS `current_status`,
 1 AS `event_type`,
 1 AS `from_status`,
 1 AS `to_status`,
 1 AS `note`,
 1 AS `operator_name`,
 1 AS `event_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_service_public_list`
--

DROP TABLE IF EXISTS `v_service_public_list`;
/*!50001 DROP VIEW IF EXISTS `v_service_public_list`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_service_public_list` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `price`,
 1 AS `description`,
 1 AS `images`,
 1 AS `avg_score`,
 1 AS `created_at`,
 1 AS `category_name`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `provider_credit_score`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_notifications`
--

DROP TABLE IF EXISTS `v_user_notifications`;
/*!50001 DROP VIEW IF EXISTS `v_user_notifications`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_notifications` AS SELECT 
 1 AS `id`,
 1 AS `user_id`,
 1 AS `nickname`,
 1 AS `business_type`,
 1 AS `business_id`,
 1 AS `title`,
 1 AS `content`,
 1 AS `is_read`,
 1 AS `created_at`,
 1 AS `read_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_wallet_summary`
--

DROP TABLE IF EXISTS `v_user_wallet_summary`;
/*!50001 DROP VIEW IF EXISTS `v_user_wallet_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_wallet_summary` AS SELECT 
 1 AS `user_id`,
 1 AS `nickname`,
 1 AS `balance`,
 1 AS `frozen_balance`,
 1 AS `wallet_log_count`,
 1 AS `total_in`,
 1 AS `total_out`,
 1 AS `last_wallet_log_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_wallet_reconcile_source`
--

DROP TABLE IF EXISTS `v_wallet_reconcile_source`;
/*!50001 DROP VIEW IF EXISTS `v_wallet_reconcile_source`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_wallet_reconcile_source` AS SELECT 
 1 AS `order_sn`,
 1 AS `order_amount`,
 1 AS `order_status`,
 1 AS `fund_amount`,
 1 AS `fund_status`,
 1 AS `buyer_out_amount`,
 1 AS `user_in_amount`,
 1 AS `is_abnormal`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `wallet_logs`
--

DROP TABLE IF EXISTS `wallet_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `order_sn` varchar(64) DEFAULT NULL,
  `type` varchar(30) NOT NULL,
  `direction` varchar(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance_after` decimal(10,2) NOT NULL,
  `title` varchar(120) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_wallet_user_created` (`user_id`,`created_at`),
  KEY `idx_wallet_order` (`order_sn`),
  CONSTRAINT `fk_wallet_order` FOREIGN KEY (`order_sn`) REFERENCES `orders` (`order_sn`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_wallet_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_wallet_amount` CHECK ((`amount` > 0)),
  CONSTRAINT `chk_wallet_balance` CHECK ((`balance_after` >= 0)),
  CONSTRAINT `chk_wallet_direction` CHECK ((`direction` in (_utf8mb4'in',_utf8mb4'out'))),
  CONSTRAINT `chk_wallet_type` CHECK ((`type` in (_utf8mb4'recharge',_utf8mb4'pay',_utf8mb4'income',_utf8mb4'refund',_utf8mb4'withdraw',_utf8mb4'adjust')))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_logs`
--

LOCK TABLES `wallet_logs` WRITE;
/*!40000 ALTER TABLE `wallet_logs` DISABLE KEYS */;
INSERT INTO `wallet_logs` VALUES (1,1,NULL,'recharge','in',128.60,128.60,'演示充值','小程序演示账户充值','2026-06-12 09:00:00'),(2,1,'CT202606120001','pay','out',26.00,102.60,'支付订单 CT202606120001','资金进入订单托管账户','2026-06-12 09:50:00'),(3,1,'CT202606120002','pay','out',58.00,44.60,'支付订单 CT202606120002','资金进入订单托管账户','2026-06-12 10:00:00'),(4,1,'SV202606120001','pay','out',6.00,38.60,'预约服务 SV202606120001','服务费进入订单托管账户','2026-06-12 09:10:00'),(5,6,'ER202606110001','income','in',12.00,12.00,'跑腿收益 ER202606110001','发布者确认完成后结算','2026-06-11 20:00:00'),(6,7,'CT202606100001','pay','out',26.00,20.00,'支付订单 CT202606100001','历史成交扣款流水','2026-06-10 19:00:00'),(7,2,'CT202606100001','income','in',26.00,46.00,'订单收入 CT202606100001','历史成交结算流水','2026-06-10 20:20:00');
/*!40000 ALTER TABLE `wallet_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_wallet_logs_no_update` BEFORE UPDATE ON `wallet_logs` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'wallet_logs is append-only; create an adjusting log instead';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_wallet_logs_no_delete` BEFORE DELETE ON `wallet_logs` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'wallet_logs is append-only and cannot be deleted';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `withdraw_requests`
--

DROP TABLE IF EXISTS `withdraw_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `reviewer_id` bigint unsigned DEFAULT NULL,
  `review_note` varchar(255) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_withdraw_user_created` (`user_id`,`created_at`),
  KEY `idx_withdraw_status_created` (`status`,`created_at`),
  KEY `fk_withdraw_reviewer` (`reviewer_id`),
  CONSTRAINT `fk_withdraw_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_withdraw_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_withdraw_amount` CHECK ((`amount` > 0)),
  CONSTRAINT `chk_withdraw_status` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'approved',_utf8mb4'rejected',_utf8mb4'cancelled')))
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_requests`
--

LOCK TABLES `withdraw_requests` WRITE;
/*!40000 ALTER TABLE `withdraw_requests` DISABLE KEYS */;
INSERT INTO `withdraw_requests` VALUES (301,6,12.00,'跑腿收益提现','pending',NULL,NULL,NULL,'2026-06-12 09:35:00','2026-06-12 09:35:00');
/*!40000 ALTER TABLE `withdraw_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'campus_trade'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `ev_campus_cancel_unpaid_orders` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_campus_cancel_unpaid_orders` ON SCHEDULE EVERY 10 MINUTE STARTS '2026-06-12 14:28:28' ON COMPLETION PRESERVE DISABLE DO BEGIN
  CALL sp_cancel_unpaid_orders(NOW() - INTERVAL 30 MINUTE);
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_campus_daily_stats` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_campus_daily_stats` ON SCHEDULE EVERY 1 DAY STARTS '2026-06-13 14:18:28' ON COMPLETION PRESERVE DISABLE DO BEGIN
  CALL sp_daily_stats(CURRENT_DATE - INTERVAL 1 DAY);
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'campus_trade'
--

--
-- Current Database: `campus_trade`
--

USE `campus_trade`;

--
-- Final view structure for view `v_admin_order_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_admin_order_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_admin_order_summary` AS select `o`.`order_sn` AS `order_sn`,`o`.`item_type` AS `item_type`,`o`.`item_id` AS `item_id`,json_unquote(json_extract(`o`.`item_snapshot`,'$.title')) AS `item_title`,`o`.`amount` AS `amount`,`o`.`status` AS `order_status`,coalesce(`f`.`status`,'none') AS `fund_status`,`o`.`created_at` AS `created_at`,`o`.`paid_at` AS `paid_at`,`o`.`completed_at` AS `completed_at`,`buyer`.`nickname` AS `buyer_name`,`seller`.`nickname` AS `seller_name` from (((`orders` `o` join `users` `buyer` on((`buyer`.`id` = `o`.`buyer_id`))) join `users` `seller` on((`seller`.`id` = `o`.`seller_id`))) left join `order_funds` `f` on((`f`.`order_sn` = `o`.`order_sn`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_admin_pending_goods`
--

/*!50001 DROP VIEW IF EXISTS `v_admin_pending_goods`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_admin_pending_goods` AS select `g`.`id` AS `id`,`g`.`title` AS `title`,`g`.`price` AS `price`,`g`.`condition_level` AS `condition_level`,`g`.`description` AS `description`,`g`.`audit_note` AS `audit_note`,`g`.`created_at` AS `created_at`,`c`.`name` AS `category_name`,`u`.`nickname` AS `seller_name`,`u`.`credit_score` AS `seller_credit_score` from ((`goods` `g` join `categories` `c` on((`c`.`id` = `g`.`category_id`))) join `users` `u` on((`u`.`id` = `g`.`seller_id`))) where (`g`.`status` = 'pending') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_admin_refund_queue`
--

/*!50001 DROP VIEW IF EXISTS `v_admin_refund_queue`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_admin_refund_queue` AS select `rr`.`id` AS `refund_id`,`rr`.`order_sn` AS `order_sn`,`rr`.`reason` AS `reason`,`rr`.`evidence_urls` AS `evidence_urls`,`rr`.`status` AS `refund_status`,`rr`.`created_at` AS `created_at`,`o`.`amount` AS `amount`,`o`.`status` AS `order_status`,`applicant`.`nickname` AS `applicant_name`,`seller`.`nickname` AS `seller_name`,`admin`.`nickname` AS `admin_name` from ((((`refund_requests` `rr` join `orders` `o` on((`o`.`order_sn` = `rr`.`order_sn`))) join `users` `applicant` on((`applicant`.`id` = `rr`.`applicant_id`))) join `users` `seller` on((`seller`.`id` = `rr`.`seller_id`))) left join `users` `admin` on((`admin`.`id` = `rr`.`admin_id`))) where (`rr`.`status` in ('pending','seller_rejected','arbitrating')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_chat_evidence_chain`
--

/*!50001 DROP VIEW IF EXISTS `v_chat_evidence_chain`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_chat_evidence_chain` AS select `c`.`id` AS `conversation_id`,`c`.`business_type` AS `business_type`,`c`.`business_id` AS `business_id`,`m`.`id` AS `message_id`,`sender`.`nickname` AS `sender_name`,`receiver`.`nickname` AS `receiver_name`,`m`.`message_type` AS `message_type`,`m`.`content` AS `content`,`m`.`content_hash` AS `content_hash`,`m`.`previous_hash` AS `previous_hash`,`m`.`status` AS `status`,`m`.`created_at` AS `created_at` from (((`conversations` `c` join `messages` `m` on((`m`.`conversation_id` = `c`.`id`))) join `users` `sender` on((`sender`.`id` = `m`.`sender_id`))) join `users` `receiver` on((`receiver`.`id` = `m`.`receiver_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_errand_hall`
--

/*!50001 DROP VIEW IF EXISTS `v_errand_hall`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_errand_hall` AS select `e`.`id` AS `id`,`e`.`title` AS `title`,`e`.`description` AS `description`,`e`.`pickup_location` AS `pickup_location`,`e`.`delivery_location` AS `delivery_location`,`e`.`fee` AS `fee`,`e`.`status` AS `status`,`e`.`created_at` AS `created_at`,`publisher`.`nickname` AS `publisher_name`,`rider`.`nickname` AS `rider_name` from ((`errand_orders` `e` join `users` `publisher` on((`publisher`.`id` = `e`.`publisher_id`))) left join `users` `rider` on((`rider`.`id` = `e`.`rider_id`))) where (`e`.`status` in ('waiting_accept','accepted','processing')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_goods_public_list`
--

/*!50001 DROP VIEW IF EXISTS `v_goods_public_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_goods_public_list` AS select `g`.`id` AS `id`,`g`.`title` AS `title`,`g`.`price` AS `price`,`g`.`condition_level` AS `condition_level`,`g`.`description` AS `description`,`g`.`images` AS `images`,`g`.`location` AS `location`,`g`.`favorite_count` AS `favorite_count`,`g`.`view_count` AS `view_count`,`g`.`created_at` AS `created_at`,`c`.`name` AS `category_name`,`u`.`id` AS `seller_id`,`u`.`nickname` AS `seller_name`,`u`.`credit_score` AS `seller_credit_score` from ((`goods` `g` join `categories` `c` on((`c`.`id` = `g`.`category_id`))) join `users` `u` on((`u`.`id` = `g`.`seller_id`))) where ((`g`.`status` = 'on_sale') and (`c`.`status` = 'active') and (`u`.`status` = 'active')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_order_trace`
--

/*!50001 DROP VIEW IF EXISTS `v_order_trace`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_order_trace` AS select `o`.`order_sn` AS `order_sn`,`o`.`item_type` AS `item_type`,json_unquote(json_extract(`o`.`item_snapshot`,'$.title')) AS `item_title`,`o`.`status` AS `current_status`,`e`.`event_type` AS `event_type`,`e`.`from_status` AS `from_status`,`e`.`to_status` AS `to_status`,`e`.`note` AS `note`,`operator`.`nickname` AS `operator_name`,`e`.`created_at` AS `event_at` from ((`orders` `o` left join `order_events` `e` on((`e`.`order_sn` = `o`.`order_sn`))) left join `users` `operator` on((`operator`.`id` = `e`.`operator_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_service_public_list`
--

/*!50001 DROP VIEW IF EXISTS `v_service_public_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_service_public_list` AS select `s`.`id` AS `id`,`s`.`title` AS `title`,`s`.`price` AS `price`,`s`.`description` AS `description`,`s`.`images` AS `images`,`s`.`avg_score` AS `avg_score`,`s`.`created_at` AS `created_at`,`c`.`name` AS `category_name`,`u`.`id` AS `provider_id`,`u`.`nickname` AS `provider_name`,`u`.`credit_score` AS `provider_credit_score` from ((`services` `s` join `categories` `c` on((`c`.`id` = `s`.`category_id`))) join `users` `u` on((`u`.`id` = `s`.`provider_id`))) where ((`s`.`status` = 'on_sale') and (`c`.`status` = 'active') and (`u`.`status` = 'active')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_notifications`
--

/*!50001 DROP VIEW IF EXISTS `v_user_notifications`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_notifications` AS select `n`.`id` AS `id`,`n`.`user_id` AS `user_id`,`u`.`nickname` AS `nickname`,`n`.`business_type` AS `business_type`,`n`.`business_id` AS `business_id`,`n`.`title` AS `title`,`n`.`content` AS `content`,`n`.`is_read` AS `is_read`,`n`.`created_at` AS `created_at`,`n`.`read_at` AS `read_at` from (`notifications` `n` join `users` `u` on((`u`.`id` = `n`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_wallet_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_user_wallet_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_wallet_summary` AS select `u`.`id` AS `user_id`,`u`.`nickname` AS `nickname`,`u`.`balance` AS `balance`,`u`.`frozen_balance` AS `frozen_balance`,count(`wl`.`id`) AS `wallet_log_count`,coalesce(sum((case when (`wl`.`direction` = 'in') then `wl`.`amount` else 0 end)),0.00) AS `total_in`,coalesce(sum((case when (`wl`.`direction` = 'out') then `wl`.`amount` else 0 end)),0.00) AS `total_out`,max(`wl`.`created_at`) AS `last_wallet_log_at` from (`users` `u` left join `wallet_logs` `wl` on((`wl`.`user_id` = `u`.`id`))) group by `u`.`id`,`u`.`nickname`,`u`.`balance`,`u`.`frozen_balance` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_wallet_reconcile_source`
--

/*!50001 DROP VIEW IF EXISTS `v_wallet_reconcile_source`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_wallet_reconcile_source` AS select `o`.`order_sn` AS `order_sn`,`o`.`amount` AS `order_amount`,`o`.`status` AS `order_status`,coalesce(`f`.`amount`,0.00) AS `fund_amount`,coalesce(`f`.`status`,'missing') AS `fund_status`,coalesce(sum((case when (`wl`.`direction` = 'out') then `wl`.`amount` else 0 end)),0.00) AS `buyer_out_amount`,coalesce(sum((case when (`wl`.`direction` = 'in') then `wl`.`amount` else 0 end)),0.00) AS `user_in_amount`,(case when (`f`.`id` is null) then 1 when (`f`.`amount` <> `o`.`amount`) then 1 when ((`o`.`status` in ('paid','confirmed','shipped','refunding','disputed')) and (`f`.`status` <> 'frozen')) then 1 when ((`o`.`status` = 'completed') and (`f`.`status` <> 'settled')) then 1 when ((`o`.`status` = 'refunded') and (`f`.`status` <> 'refunded')) then 1 else 0 end) AS `is_abnormal` from ((`orders` `o` left join `order_funds` `f` on((`f`.`order_sn` = `o`.`order_sn`))) left join `wallet_logs` `wl` on((`wl`.`order_sn` = `o`.`order_sn`))) group by `o`.`order_sn`,`o`.`amount`,`o`.`status`,`f`.`id`,`f`.`amount`,`f`.`status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-12 14:20:33
